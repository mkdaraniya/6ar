<?php
class Mobicommerce_Mobiadmin_Model_Devicetokens extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('mobiadmin/devicetokens');
    }	
}