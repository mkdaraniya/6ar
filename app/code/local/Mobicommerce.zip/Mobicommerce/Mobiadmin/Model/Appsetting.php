<?php
class Mobicommerce_Mobiadmin_Model_Appsetting extends Mage_Core_Model_Abstract {
    protected function _construct()
    {
        $this->_init('mobiadmin/appsetting');
    }
}