<?php
class Mobicommerce_Mobiadmin_Block_Adminhtml_Applications_Edit_Tab_Personalization extends Mage_Adminhtml_Block_Template {
	
	public function __construct()
    {
        parent::__construct();
        $this->setTemplate('mobiadmin/application/edit/tab/personalization.phtml');
    }
}