<?php
class Mobicommerce_Mobiadmin_Block_Adminhtml_Applications_Edit_Tab_Productslider extends Mage_Adminhtml_Block_Template {
	
	public function __construct()
    {
        parent::__construct();
        $this->setTemplate('mobiadmin/application/edit/tab/productslider.phtml');
    }
}