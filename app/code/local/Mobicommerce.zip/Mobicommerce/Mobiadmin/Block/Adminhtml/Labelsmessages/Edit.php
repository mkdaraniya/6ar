<?php
class Mobicommerce_Mobiadmin_Block_Adminhtml_Labelsmessages_Edit extends Mage_Adminhtml_Block_Widget_Form_Container {
	
	public function __construct()
    {
		$this->_blockGroup = 'mobiadmin';
		$this->_mode = 'edit';  
		$this->_controller = 'adminhtml_labelsmessages';
		$this->_updateButton('save', 'label', 'Save');
		$this->_removeButton('delete');
		$this->_removeButton('back');
		parent::__construct();
	}

	public function getHeaderText()
    {
        return $this->__('Labels and Messages');
    }
}