<?php
class Mobicommerce_Mobiadmin_Block_Adminhtml_Applications_Edit_Tab_Pushnotifications extends Mage_Adminhtml_Block_Widget_Form {
	
    protected function _prepareForm()
	{
	    $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset('push_notification', array('legend'=>$this->__('Push Notifications <span class="app-scope">[Website]</span>')));
		$fieldset->addField('note', 'note', array(
          	'text' => Mage::helper('mobiadmin')->__($this->__('Send push notification to users. Enter the message and send to all users who are using the App.')),
        	));

		$fieldset->addField('pushheading', 'text', array(
			'label'              => Mage::helper('mobiadmin')->__($this->__('Heading')),
			'name'               => 'pushheading',
        	));

		$fieldset->addField('pushnotifications', 'textarea', array(
			'label'              => Mage::helper('mobiadmin')->__($this->__('Message')),
			'name'               => 'pushnotifications',
			'maxlength'          => '255',
			'after_element_html' => '<br><small>'.$this->__('Notification Maximum Text Length is 255 Characters').'</small>',
        	));
    }
}