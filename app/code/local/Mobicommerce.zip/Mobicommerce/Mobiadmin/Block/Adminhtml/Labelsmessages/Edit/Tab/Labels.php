<?php
class Mobicommerce_Mobiadmin_Block_Adminhtml_Labelsmessages_Edit_Tab_Labels extends Mage_Adminhtml_Block_Widget_Form {
	
	protected function _prepareForm()
    {
	    $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset('labels_data', array('legend'=>$this->__('Label')));
        $locale = $this->getRequest()->getParam('lang_code', null);
        $labels = Mage::helper('mobiadmin')->getLanguageData($locale);
        
		foreach ($labels as $key => $label) {
			if($label['mm_type'] == 'label') {
				$fieldset->addField('message-label'.$key, 'text', array(
					'label'      => Mage::helper('mobiadmin')->__($label['mm_label']),
					'required'   => false,
					'name'       => "language_data[".$key."]",
					'value'      => isset($childlabels[$key]['mm_text']) ? $childlabels[$key]['mm_text'] : $label['mm_text'],
					'maxlength'  => $label['mm_maxlength'],
					));
			}
		}
	}
}