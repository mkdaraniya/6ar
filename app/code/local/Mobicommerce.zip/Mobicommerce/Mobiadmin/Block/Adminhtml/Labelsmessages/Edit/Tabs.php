<?php
class Mobicommerce_Mobiadmin_Block_Adminhtml_Labelsmessages_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs 
{
	public function __construct()
	{
		parent::__construct();
		$this->setId('labelsmessages_data');
		$this->setDestElementId('edit_form');
		$this->setTitle($this->__('Labels and Messages'));
	}

	protected function _beforeToHtml()
	{
		$this->addTab('labels', array(
			'label'   => $this->__('Labels'),
			'title'   => $this->__('Labels'),
			'content' => $this->getLayout()->createBlock('mobiadmin/adminhtml_labelsmessages_edit_tab_labels')->toHtml()
		));
		$this->addTab('messages', array(
			'label'   => $this->__('Messages'),
			'title'   => $this->__('Messages'),
			'content' => $this->getLayout()->createBlock('mobiadmin/adminhtml_labelsmessages_edit_tab_messages')->toHtml()
		));
		return parent::_beforeToHtml();
	}
}