<?php
class Mobicommerce_Mobiadmin_Block_Adminhtml_Applications_Edit_Tab_Categoryicon extends Mage_Adminhtml_Block_Template {
	
	public function __construct()
    {
        parent::__construct();
        $this->setTemplate('mobiadmin/application/edit/tab/icon.phtml');
    }
}