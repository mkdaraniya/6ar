<?php

class Mobicommerce_Mobiservices_Model_1x4x0_Newsletter extends Mobicommerce_Mobiservices_Model_Abstract {

	public function save($data)
    {
        try {
            $is_subscribed = false;
            if(isset($data['is_subscribed']) && !empty($data['is_subscribed'])){
                $is_subscribed = true;
            }
            Mage::getSingleton('customer/session')->getCustomer()
            ->setStoreId(Mage::app()->getStore()->getId())
            ->setIsSubscribed($is_subscribed)
            ->save();

            $result = $this->successStatus();
            if ($is_subscribed) {
                $result['message'] = Mage::helper('core')->__('The subscription has been saved.');
            } else {
                $result['message'] = Mage::helper('core')->__('The subscription has been removed.');
            }
            $result['data']['cart_details'] = Mage::getModel(Mage::getBlockSingleton('mobiservices/connector')->_getConnectorModel('mobiservices/shoppingcart_cart'))->getCartInfo();
            return $result;
        }
        catch (Exception $e) {
            return $this->errorStatus(Mage::helper('core')->__('An error occurred while saving your subscription.'));
        }
        return $this->errorStatus(Mage::helper('core')->__('An error occurred while saving your subscription.'));
    }

    public function isSubscribed($_customer)
    {
        $subscriber = Mage::getModel('newsletter/subscriber')->loadByCustomer($_customer);
        if($subscriber->isSubscribed())
            return true;
        else
            return false;
    }
}