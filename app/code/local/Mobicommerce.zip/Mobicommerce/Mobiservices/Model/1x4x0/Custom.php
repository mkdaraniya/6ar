<?php

class Mobicommerce_Mobiservices_Model_1x4x0_Custom extends Mobicommerce_Mobiservices_Model_Abstract {

    const REFRESH_CART_AFTER_ADD_PRODUCT = false;
    const IS_SHIPPING_METHOD_CUSTOM_FIELDS = false;
    const ROUNDUP_CART_VALUES = false;
    const DNB_DESIGNTOOL_APPLIED = false;
    private $customModules;

    public function __construct()
    {
        parent::__construct();
        $this->customModules = array(
            'Mage_Newsletter',
            //'Mirasvit_Rewards'
            );
    }

	public function getCustomCheckoutFields()
    {
        $customFields = array();
        $site = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
        
        // P01
        $customFields = array(
            "register" => array(
                array(
                    "code"              => "taxvat",
                    "type"              => "text",
                    "name"              => "Codice Fiscale",
                    "required"          => true,
                    "validation"        => "",
                    "error_message"     => "Questo è un campo obbligatorio.",
                    "registerDependent" => false
                    )
                ),
            "billing" => array(
                array(
                    "code"              => "taxvat",
                    "type"              => "text",
                    "name"              => "Codice Fiscale",
                    "required"          => true,
                    "validation"        => "",
                    "error_message"     => "Questo è un campo obbligatorio.",
                    "registerDependent" => true
                    ),
                ),
            );
        // F03
        $customFields = array(
            "shipping_method" => array(
                array(
                    "code"              => "adj[delivery_date]",
                    "type"              => "date",
                    "name"              => "Leveringsdatum",
                    "required"          => true,
                    "validation"        => "",
                    "error_message"     => "Please enter delivery date",
                    "registerDependent" => false,
                    "params" => array(
                        "default_value" => "",
                        "description"   => "",
                        "format"        => "dd/mm/yyyy"
                        )
                    )
                ),
            );
        // for emmanual trucksdepot
        $customFields = array(
            "order_review" => array(
                array(
                    "code"              => "ordercomment[comment]",
                    "type"              => "textarea",
                    "name"              => "Order Comment",
                    "required"          => false,
                    "validation"        => "",
                    "error_message"     => "",
                    "registerDependent" => false,
                    "params" => array(
                        "default_value" => "",
                        "description"   => "",
                        "format"        => ""
                        )
                    )
                ),
            );
        //p08
        $customFields = array(
            "register" => array(
                array(
                    "code"              => "gender",
                    "type"              => "dropdown",
                    "options"           => array("1" => "Male", "2" => "Female"),
                    "name"              => "Gender",
                    "required"          => true,
                    "validation"        => "",
                    "error_message"     => "Please select gender",
                    "registerDependent" => false
                    )
                ),
            );
        $customFields = array(
            "billing" => array(
                array(
                    "code"              => "mobile",
                    "type"              => "text",
                    "name"              => "Mobile",
                    "required"          => true,
                    "validation"        => "",
                    "error_message"     => "Mobile number field is required",
                    "registerDependent" => false
                    ),
                ),
            "shipping" => array(
                array(
                    "code"              => "mobile",
                    "type"              => "text",
                    "name"              => "Mobile",
                    "required"          => true,
                    "validation"        => "",
                    "error_message"     => "Mobile number field is required",
                    "registerDependent" => false
                    ),
                ),
            );
        //aala
        $customFields = array(
            "myaccount" => array(
                array(
                    "code"              => "dob",
                    "type"              => "date",
                    "name"              => "Date Of Birth",
                    "required"          => true,
                    "validation"        => "",
                    "error_message"     => "Please enter date of birth",
                    "registerDependent" => false,
                    "params" => array(
                        "default_value" => "",
                        "description"   => "",
                        "format"        => "dd/mm/yyyy",
                        "parts"         => 3
                        )
                    ),
                array(
                    "code"              => "gender",
                    "type"              => "dropdown",
                    "options"           => array("1" => "Male", "2" => "Female"),
                    "name"              => "Gender",
                    "required"          => true,
                    "validation"        => "",
                    "error_message"     => "Please select gender",
                    "registerDependent" => false
                    )
                ),
            "order_review" => array(
                array(
                    "code"              => "cdr_ordercomment",
                    "type"              => "textarea",
                    "name"              => "Order Comment",
                    "required"          => false,
                    "validation"        => "",
                    "error_message"     => "",
                    "registerDependent" => false,
                    "params" => array(
                        "default_value" => "",
                        "description"   => "",
                        "format"        => ""
                        )
                    )
                ),
            );
        $customFields = array();
        return $customFields;
    }

    public function getCustomProductDetailFields($_product, $productInfo)
    {
        $fields = array(
            array(
                "code"     => "sku",
                "type"     => "text",
                "relateTo" => "description",
                "name"     => "Codice",
                "value"    => "",
                ),
            array(
                "code"     => "manufacturer",
                "type"     => "dropdown",
                "relateTo" => "description",
                "name"     => "Marchio",
                "value"    => "",
                ),
            array(
                "code"     => "consegna_time",
                "type"     => "text",
                "relateTo" => "description",
                "name"     => "Tempo di Consegna",
                "value"    => "",
                ),
            array(
                "code"     => "generic_group",
                "type"     => "dropdown",
                "relateTo" => "description",
                "name"     => "Reparto",
                "value"    => "",
                ),
            array(
                "code"     => "custom_stock_status",
                "type"     => "dropdown",
                "relateTo" => "stock",
                "name"     => "Disponibilità",
                "value"    => "",
                ),
            );
        $fields = array(
            array(
                "code"     => "size_chart",
                "type"     => "text",
                "relateTo" => "staticblock_identifier",
                "name"     => "SIZE CHART & GARMENT INFO",
                "value"    => "",
                ),
            );
        // F17
        $fields = array(
            array(
                "code"     => "payuapi",
                "type"     => "payment_method_installments",
                "relateTo" => "payment_method_installments",
                "name"     => "TAKSİT SEÇENEKLERİ",
                "value"    => null,
                ),
            array(
                "code"     => "Options",
                "type"     => "group_attribute",
                "relateTo" => "group_attribute",
                "name"     => "ÖZELLİKLER",
                "value"    => "",
                ),
            array(
                "code"     => "returns_custom_tab_tr",
                "type"     => "staticblock_identifier",
                "relateTo" => "staticblock_identifier",
                "name"     => "GARANTİ",
                "value"    => "",
                ),
            array(
                "code"     => "payment_custom_tab",
                "type"     => "staticblock_identifier",
                "relateTo" => "staticblock_identifier",
                "name"     => "Ödeme",
                "value"    => "",
                ),
            array(
                "code"     => "shipping_custom_tab_tr",
                "type"     => "staticblock_identifier",
                "relateTo" => "staticblock_identifier",
                "name"     => "KARGO",
                "value"    => "",
                ),
            );
        // Dnb mobi
        $fields = array(
            array(
                "code"     => "is_customizable",
                "type"     => "dropdown",
                "relateTo" => "DNBDESIGNTOOL_BUTTON",
                "name"     => "Personalize",
                "value"    => "",
                ),
            );
        //babylife
        $fields = array(
            array(
                "code"     => "cjm_stockmessage",
                "type"     => "text",
                "relateTo" => "stock",
                "name"     => "Availability",
                "value"    => "",
                ),
            );
        // for julicci
        $fields = array(
            array(
                "code"     => "sizing-chart",
                "type"     => "cms_identifier",
                "relateTo" => "popup_image",
                "name"     => "SIZE CHART",
                "value"    => "",
                ),
            );
        // for aala
        $fields = array(
            array(
                "code"     => "block_product_tab1",
                "type"     => "staticblock_identifier",
                "relateTo" => "staticblock_identifier",
                "name"     => "While Ordering On Internet",
                "value"    => "",
                ),
            );
        $fields = null;
        $outputFields = array();
        if(!empty($fields)){
            foreach($fields as $field_key => $field){
                try{
                    if(in_array($field['type'], array('text', 'dropdown'))){
                        if($_product->offsetExists($field['code'])){
                            switch ($field['type']) {
                                case 'text':
                                default:
                                    $fields[$field_key]['value'] = $_product->getResource()->getAttribute($field['code'])->getFrontend()->getValue($_product);
                                    break;
                                case 'dropdown':
                                    if($field['code'] == 'is_customizable'){
                                        $fields[$field_key]['value'] = strtolower($_product->getResource()->getAttribute($field['code'])->getFrontend()->getValue($_product)) == 'sí' ? 'Yes' : false;
                                    }
                                    else{
                                        $fields[$field_key]['value'] = $_product->getAttributeText($field['code']);
                                    }
                                    break;
                            }
                            switch ($field['relateTo']) {
                                case 'stock':
                                    $stock = Mage::getModel('cataloginventory/stock_item')->loadByProduct($_product);
                                    $fields[$field_key]['value'] = str_replace('{qty}', (int)$stock->getQty(), $fields[$field_key]['value']);
                                    break;
                                case 'staticblock_identifier':
                                    $fields[$field_key]['value'] = Mage::app()->getLayout()->createBlock('cms/block')->setBlockId($fields[$field_key]['value'])->toHtml();
                                    break;
                                default:
                                    break;
                            }
                            $outputFields[] = $fields[$field_key];
                        }
                    }
                    else if(in_array($field['type'], array('staticblock_identifier'))){
                        $fields[$field_key]['value'] = Mage::app()->getLayout()->createBlock('cms/block')->setBlockId($fields[$field_key]['code'])->toHtml();
                        $outputFields[] = $fields[$field_key];
                    }
                    else if(in_array($field['type'], array('cms_identifier'))){
                        $fields[$field_key]['value'] = Mage::helper('cms')->getPageTemplateProcessor()->filter(Mage::getModel('cms/page')->load($fields[$field_key]['code'], 'identifier')->getContent());
                        $outputFields[] = $fields[$field_key];
                    }
                    else if(in_array($field['type'], array('group_attribute'))){
                        $groupId = Mage::getModel('eav/entity_attribute_group')->getCollection()
                            ->addFieldToFilter('attribute_set_id', array('eq' => $_product->getAttributeSetId()))
                            ->addFieldToFilter('attribute_group_name', array('eq' => $field['code']))
                            ->getFirstItem()->getId();

                        $product_attributes = array();
                        foreach($_product->getAttributes($groupId) as $attribute) {
                            $product_attributes[] = array(
                                'frontend_label' => $attribute->getFrontend()->getLabel($_product),
                                'store_label'    => $attribute->getStoreLabel(),
                                'value'          => $attribute->getFrontend()->getValue($_product)
                                );
                        }
                        $fields[$field_key]['value'] = $product_attributes;
                        $outputFields[] = $fields[$field_key];
                    }
                    else if(in_array($field['type'], array('payment_method_installments'))){
                        $payments = Mage::getSingleton('payment/config')->getActiveMethods();
                        $product_price = $_product->getFinalPrice();
                        if($payments){
                            foreach ($payments as $method_code => $method) {
                                if($method_code == $field['code']){
                                    switch($method_code){
                                        case 'payuapi';
                                            $installment_options = array();
                                            $installment_key_pair = array(
                                                array(
                                                    "name"      => "Axess, Bonus, Maximum, Finans, World, Asya, Halkbank",
                                                    "keycode"   => "V7H1993D1",
                                                    "valuecode" => "VGD8UEY31",
                                                    "is_active" => false,
                                                    "options"   => array()
                                                    ),
                                                /*
                                                array(
                                                    "name"      => "Installment - Bonus",
                                                    "keycode"   => "V7H1993D2",
                                                    "valuecode" => "VGD8UEY32",
                                                    "is_active" => false,
                                                    "options"   => array()
                                                    ),
                                                array(
                                                    "name"      => "Installment - Maximum",
                                                    "keycode"   => "V7H1993D3",
                                                    "valuecode" => "VGD8UEY33",
                                                    "is_active" => false,
                                                    "options"   => array()
                                                    ),
                                                array(
                                                    "name"      => "Installment - Finans",
                                                    "keycode"   => "V7H1993D4",
                                                    "valuecode" => "VGD8UEY34",
                                                    "is_active" => false,
                                                    "options"   => array()
                                                    ),
                                                array(
                                                    "name"      => "Installment - World",
                                                    "keycode"   => "V7H1993D5",
                                                    "valuecode" => "VGD8UEY35",
                                                    "is_active" => false,
                                                    "options"   => array()
                                                    ),
                                                array(
                                                    "name"      => "Installment - Asya",
                                                    "keycode"   => "V7H1993D6",
                                                    "valuecode" => "VGD8UEY36",
                                                    "is_active" => false,
                                                    "options"   => array()
                                                    ),
                                                array(
                                                    "name"      => "Installment - Halkbank",
                                                    "keycode"   => "V7H1993D7",
                                                    "valuecode" => "VGD8UEY37",
                                                    "is_active" => false,
                                                    "options"   => array()
                                                    )
                                                */
                                                );
                                            foreach($installment_key_pair as $installment_key => $installment_pair){
                                                if($method->getConfigData($installment_pair['keycode'])){
                                                    $installment_key_pair[$installment_key]['is_active']   = true;
                                                    $installment_key_pair[$installment_key]['options_str'] = $method->getConfigData($installment_pair['valuecode']);
                                                    $installment_key_pair[$installment_key]['options']     = $this->_processPayuapiInstallmentOptionsString($installment_key_pair[$installment_key]['options_str'], $product_price, $interest_type = 'simple', $force_yearly_interest = true);

                                                    $installment_options[] = $installment_key_pair[$installment_key];
                                                }
                                            }

                                            $fields[$field_key]['value'] = $installment_options;
                                            $outputFields[] = $fields[$field_key];
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                        }
                    }
                }
                catch(Exception $e){
                    
                }
            }
        }

        $autoOutputFields = $this->getAdditionalData($_product);
        $outputFields = array_merge($outputFields, $autoOutputFields);
        /* for oxolloxo */
        /*
        $outputFields[] = array(
            "code"     => "size_chart",
            "relateTo" => "popup_image",
            "name"     => "Size Chart",
            "value"    => Mage::helper('catalog/image')->init($_product, 'size_chart')->resize(200)->__toString(),
            );
        */
        if(empty($outputFields))
            $outputFields = null;
        
        //$outputFields = null;
        $productInfo['customAttributes'] = $outputFields;
        return $productInfo;
    }

    public function getAdditionalData($product)
    {
        $data = array();
        $excludeAttr = array();
        $attributes = $product->getAttributes();
        foreach($attributes as $attribute){
            if($attribute->getIsVisibleOnFront() && !in_array($attribute->getAttributeCode(), $excludeAttr)){
                $value = $attribute->getFrontend()->getValue($product);

                if(!$product->hasData($attribute->getAttributeCode())) {
                    $value = Mage::helper('catalog')->__('N/A');
                } elseif((string)$value == '') {
                    $value = Mage::helper('catalog')->__('No');
                } elseif($attribute->getFrontendInput() == 'price' && is_string($value)) {
                    $value = Mage::app()->getStore()->convertPrice($value, true);
                }

                if(is_string($value) && strlen($value)) {
                    $data[] = array(
                        'name'     => $attribute->getStoreLabel(),
                        'relateTo' => 'description',
                        'value'    => $value,
                        'code'     => $attribute->getAttributeCode()
                    );
                }
            }
        }
        return $data;
    }

    /**
     * Coded by Yash
     * Date: 18-12-2014
     * For calculating simple and compund interest for installment options
     */
    public function _processPayuapiInstallmentOptionsString($str = null, $price = 0, $interest_type = 'simple', $force_yearly_interest = false)
    {
        $str = trim($str);
        if(empty($str))
            return null;

        /**
         * Formula for simple interest
         * A = P(1 + rt)
         * P = principal amount
         * r = rate of interest
         * t = time(in tems of years)
         * calculating months to years
         * 2 months = 2 / 12 = 0.17 years
         */
        $return_options = array();
        $installment_options = explode(';', $str);
        foreach($installment_options as $ioption){
            $month_interest_pair = explode('=', $ioption);
            if(count($month_interest_pair) == 2){
                $month_count = $month_interest_pair[0];
                $interest_rate = $month_interest_pair[1];
                if($interest_type == 'simple'){
                    $t = 1;
                    if($force_yearly_interest)
                        $t = ceil($month_count / 12);
                    else
                        $t = round($month_count / 12, 2);

                    $r = $interest_rate / 100;
                    $total_amount = $price * (1 + ($r * $t));
                    $return_options[] = array(
                        'month_count'        => $month_count,
                        'installment_amount' => round($total_amount / $month_count),
                        'total_amount'       => round($total_amount),
                        'exact_total_amount' => round($total_amount, 2)
                        );
                }
                else if($interest_type == 'compound'){

                }
            }
        }
        return $return_options;
    }

    /**
     * for ahead works auto related products
     */
    public function getAheadWorksRelatedProducts($product, $type='related', $limit=10)
    {
        $model = Mage::getModel('awautorelated/blocks_product_rulerelated');
        $model->setWebsiteIds(Mage::app()->getStore()->getWebsite()->getId());
        $conditions = array(
            'order' => array(
                'type'      => '1',
                'attribute' => 'custom_design_from',
                'direction' => 'ASC'
                ),
            'show_out_of_stock' => '0',
            'conditions' => array(
                'type'       => 'awautorelated/catalogrule_rule_condition_combine',
                'aggregator' => 'all',
                'value'      => '1',
                'new_child'  => ''
                )
            );
        $mIds = array();
        $gCondition = array(
            array(
                'att' => 'category_ids',
                'condition' => '!='
                ),
            array(
                'att' => 'aw_shopbybrand_brand',
                'condition' => '='
                ),
            );
        if($type == 'you_may_also_like'){
            $gCondition = array(
                array(
                    'att' => 'category_ids',
                    'condition' => 'LIKE'
                    ),
                array(
                    'att' => 'aw_shopbybrand_brand',
                    'condition' => '!='
                    ),
                );
        }

        if (!empty($gCondition)) {
            $filteredIds = $this->filterByAtts($product, $gCondition, $mIds, $type);
        }
        //print_r($filteredIds);
        if (!empty($filteredIds)) {
            $filteredIds = array_diff($filteredIds, array($product->getId()));
            $filteredIds = array_diff($filteredIds, Mage::helper('awautorelated')->getWishlistProductsIds());
            $filteredIds = array_diff($filteredIds, Mage::getSingleton('checkout/cart')->getProductIds());
            $filteredIds = array_intersect($filteredIds, $this->_collection->getAllIds());
            $itemsCount = count($filteredIds);

            if (!$itemsCount) {
                unset($this->_collection);
                return null;
            }
            $this->_initCollectionForIds($filteredIds, true, $limit);
            $this->_collection->setPageSize($limit);
            $this->_collection->setCurPage(1);
        } else {
            //unset($this->_collection);
            return null;
        }

        $relatedProducts = array();
        if($this->_collection->count() > 0){
            foreach($this->_collection as $_collection){
                $productData = Mage::getModel('catalog/product')->load($_collection->getId());
                $row = array(
                    "entity_id"             => $productData['entity_id'],
                    "entity_type_id"        => $productData['entity_type_id'],
                    "attribute_set_id"      => $productData['attribute_set_id'],
                    "type_id"               => $productData['type_id'],
                    "sku"                   => $productData['sku'],
                    "price"                 => Mage::helper('mobiservices/mobicommerce')->getProductPriceByCurrency($productData->getPrice()),
                    "final_price"           => Mage::helper('mobiservices/mobicommerce')->getProductPriceByCurrency($productData->getFinalPrice()),
                    "special_price"         => Mage::helper('mobiservices/mobicommerce')->getProductPriceByCurrency($productData->getFinalPrice()),
                    "name"                  => $productData['name'],
                    "is_salable"            => $productData['is_salable'],
                    "status"                => $productData['status'],
                    "product_thumbnail_url" => Mage::helper('catalog/image')->init($productData, 'thumbnail')->resize(600)->__toString(),
                    );

                $prices = Mage::getModel(Mage::getBlockSingleton('mobiservices/connector')->_getConnectorModel('mobiservices/catalog_catalog'))->_productPrices($productData);
                if($prices){
                    $row = array_merge($row, $prices);
                }

                $relatedProducts[] = $row;
            }
        }

        return $relatedProducts;
    }

    public function filterByAtts(Mage_Catalog_Model_Product $currentProduct, $atts, $ids = null, $type)
    {
        $this->_joinedAttributes = array();
        $this->_collection = Mage::getModel('awautorelated/product_collection');
        $this->_collection->addAttributeToSelect('*');

        $_visibility = array(
            Mage_Catalog_Model_Product_Visibility::VISIBILITY_BOTH,
            Mage_Catalog_Model_Product_Visibility::VISIBILITY_IN_CATALOG
        );

        $this->_collection
            ->addAttributeToFilter('visibility', $_visibility)
            ->addAttributeToFilter('status',
                array(
                     'in' => Mage::getSingleton("catalog/product_status")->getVisibleStatusIds()
                )
            )
        ;

        Mage::getSingleton('cataloginventory/stock')->addInStockFilterToCollection($this->_collection);
        $this->_collection
            ->getSelect()
            ->join(
                array(
                     'inv_stock_status' => $this->_collection->getTable('cataloginventory/stock_status')
                ),
                'inv_stock_status.product_id = e.entity_id AND inv_stock_status.stock_status = 1',
                array()
            )
        ;

        $this->_collection
            ->addStoreFilter($this->_getStoreId())
            ->joinCategoriesByProduct()
            ->groupByAttribute('entity_id')
        ;
        $collection = $this->_collection;
        //echo $this->_collection->count();exit;//4183
        $rule = new AW_Autorelated_Model_Blocks_Rule();
        foreach ($atts as $at) {
            /*
            *  collect category ids related to product
            *  If category is anchor we should implode all of its subcategories as value
            *  If it's not we should get only its id
            *  If there is no category in product, get all categories product is in
            */
            if ($at['att'] == 'category_ids') {
                $category = $currentProduct->getCategory();
                if ($category instanceof Varien_Object) {
                    if ($category->getIsAnchor()) {
                        $value = $category->getAllChildren();
                    } else {
                        $value = $category->getId();
                    }
                } else {
                    $value = implode(',', $currentProduct->getCategoryIds());
                    $value = !empty($value) ? $value : null;
                }
                /* custom code by yash */
                if($type == 'related'){
                    $categories = $currentProduct->getCategoryIds();
                    if(!empty($categories)){
                        $category = Mage::getSingleton('core/session')->getMobiCategory();
                        if(!empty($category) && in_array($category, $categories)){
                            $value = $category;
                        }
                        else{
                            foreach($categories as $_category){
                                $_category = Mage::getModel('catalog/category')->load($_category);
                                if($_category['children_count'] == 0){
                                    $value = $_category->getId();
                                    break;
                                }
                            }
                        }
                    }
                }
                /* custom code by yash - upto here */
            } elseif ($at['att'] == 'price') {
                $value = $currentProduct->getFinalPrice();
            } else {
                $value = $currentProduct->getData($at['att']);
            }
            if (!$value) {
                $collection = NULL;
                return false;
            }
            $sql = $rule->prepareSqlForAtt($at['att'], $this->_joinedAttributes, $collection, $at['condition'], $value);
            if ($sql) {
                $collection->getSelect()->where($sql);
            }
        }
        if ($ids) {
            $collection->getSelect()->where('e.entity_id IN(' . implode(',', $ids) . ')');
        }
        $collection->getSelect()->group('e.entity_id');
        //echo $collection->getSelect();exit;
        return $collection->getAllIds();
    }

    public function _initCollectionForIds(array $ids, $sort = true, $limit)
    {
        unset($this->_collection);
        $this->_collection = Mage::getModel('awautorelated/product_collection');

        //init sort by
        if (true === $sort) {
            $ids = array_unique($ids);
            $orderSettings = 'random';
            switch ($orderSettings) {
                //case AW_Autorelated_Model_Source_Block_Common_Order::RANDOM:
                case 'random':
                    shuffle($ids);
                    if (count($ids) > $limit) {
                        array_splice($ids, $limit);
                    }
                    $this->_collection->getSelect()->order(new Zend_Db_Expr('RAND()'));
                    break;
            }
        }

        $this->_collection
            ->addAttributeToSelect('*')
            ->addFilterByIds($ids)
            ->setStoreId($this->_getStoreId())
        ;
        return $this->_collection;
    }

    public function getCustomModules()
    {
        return $this->customModules;
    }
}