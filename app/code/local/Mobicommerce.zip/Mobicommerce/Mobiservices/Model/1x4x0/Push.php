<?php

class Mobicommerce_Mobiservices_Model_1x4x0_Push extends Mobicommerce_Mobiservices_Model_Abstract {

	public function saveDeviceToken($data = array())
    {
        $appcode     = isset($data['appcode']) ? $data['appcode'] : NULL;
        $platform    = isset($data['platform']) ? $data['platform'] : NULL;
        $devicetoken = isset($data['devicetoken']) ? $data['devicetoken'] : NULL;

        if(empty($appcode) || empty($platform) || empty($devicetoken)){
            return $this->errorStatus("Please pass proper data");
        }
        else{
            if($this->commonapp_url == ''){
                $collection = Mage::getModel('mobiadmin/devicetokens')->getCollection()
                    ->addFieldToFilter('md_appcode', $appcode)
                    ->addFieldToFilter('md_devicetype', $platform)
                    ->addFieldToFilter('md_devicetoken', $devicetoken);

                if($collection->count() == 0){
                    Mage::getModel('mobiadmin/devicetokens')->setData(array(
                        'md_appcode'     => $appcode,
                        'md_devicetype'  => $platform,
                        'md_devicetoken' => $devicetoken
                        ))->save();
                }
            }
            else{
                $ch = curl_init();
                $senddata = array(
                    'platform'    => $platform,
                    'devicetoken' => $devicetoken
                    );
                curl_setopt($ch, CURLOPT_URL, $this->commonapp_url . 'apps/savedevicetoken');
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_AUTOREFERER, true);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($ch, CURLOPT_POST, count($senddata));
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($senddata));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,45); 
                curl_setopt($ch, CURLOPT_TIMEOUT, 45);
                curl_exec($ch);
                curl_close($ch);
            }

            return $this->successStatus();
        }
    }
}