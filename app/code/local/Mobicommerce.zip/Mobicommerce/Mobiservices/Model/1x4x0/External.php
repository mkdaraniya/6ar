<?php

class Mobicommerce_Mobiservices_Model_1x4x0_External extends Mobicommerce_Mobiservices_Model_Abstract
{
    public function __install102ScriptAction()
    {
        
    }
}