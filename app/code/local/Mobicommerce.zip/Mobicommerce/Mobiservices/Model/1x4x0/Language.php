<?php

class Mobicommerce_Mobiservices_Model_1x4x0_Language extends Mobicommerce_Mobiservices_Model_Abstract {
	
	public function getLanguageData($locale = 'en_US')
	{
		$labels = Mage::helper('mobiadmin')->getLanguageData($locale);
		$languageArray = array();
		foreach($labels as $key => $label){
			$languageArray[$key] = array(
				'text' => $label['mm_text'],
				);
		}
		return array($locale => array('labels' => $languageArray));;
	}
}