<?php

class Mobicommerce_Mobiservices_Model_1x4x0_Appsetting extends Mobicommerce_Mobiservices_Model_Abstract {
	
	public function getCmsdata($data)
	{
		$storeid = Mage::app()->getStore()->getStoreId();
		$cmsCollection = Mage::getModel('mobiadmin/appsetting')->getCollection()
			->addFieldToFilter('app_code', $data['appcode'])
			->addFieldToFilter('storeid', $storeid)
			->addFieldToFilter('setting_code', 'cms_settings');

		if($cmsCollection->getSize()){
			foreach($cmsCollection as $cmsData){
				$value = Mage::helper('mobiadmin')->_jsonUnserialize($cmsData['value']);
				if(isset($value['en_US']['cms_pages']) && !empty($value['en_US']['cms_pages'])){
					foreach($value['en_US']['cms_pages'] as $_page_key => $_page){
						if(strpos($_page['page_content'], 'MOBICOMMERCE_STATICBLOCK') !== FALSE){
							$staticblock = explode('MOBICOMMERCE_STATICBLOCK=', $_page['page_content']);
							$staticblock = $staticblock[1];
							$value['en_US']['cms_pages'][$_page_key]['page_content'] = Mage::app()->getLayout()->createBlock('cms/block')->setBlockId($staticblock)->toHtml();
						}
					}
				}
				return $value;
			}
		}
		else{
			return null;
		}
	}

	public function getAppinfo($data)
	{
		if($this->commonapp_url == ''){
			$appinfoCollection = Mage::getModel('mobiadmin/appsetting')->getCollection()
				->addFieldToFilter('app_code', $data['appcode'])
				->addFieldToFilter('setting_code', 'appinfo');

			if($appinfoCollection->getSize()){
				foreach($appinfoCollection as $appinfo){
					return Mage::helper('mobiadmin')->_jsonUnserialize($appinfo['value']);
				}
			}
			else{
				return null;
			}
		}
		else{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $this->commonapp_url . 'apps/getinfo');
			curl_setopt($ch, CURLOPT_HEADER, false);
			curl_setopt($ch, CURLOPT_AUTOREFERER, true);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,45); 
			curl_setopt($ch, CURLOPT_TIMEOUT, 45);
			$result = curl_exec($ch);
			curl_close($ch);
			$result = json_decode($result, true);
			return $result['data']['info'];
		}
	}

	public function getPushdata($data)
	{
		if($this->commonapp_url == ''){
			$pushCollection = Mage::getModel('mobiadmin/appsetting')->getCollection()
				->addFieldToFilter('app_code', $data['appcode'])
				->addFieldToFilter('setting_code', 'push_notification');

			if($pushCollection->getSize()){
				foreach($pushCollection as $pushCollection){
					return Mage::helper('mobiadmin')->_jsonUnserialize($pushCollection['value']);
				}
			}
			else{
				return null;
			}
		}
		else{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $this->commonapp_url . 'apps/getpushinfo');
			curl_setopt($ch, CURLOPT_HEADER, false);
			curl_setopt($ch, CURLOPT_AUTOREFERER, true);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,45); 
			curl_setopt($ch, CURLOPT_TIMEOUT, 45);
			$result = curl_exec($ch);
			curl_close($ch);
			$result = json_decode($result, true);
			return $result['data']['info'];
		}
	}

	public function getHomepageBanners($data)
	{
		$bannersArray = array();
		$storeid = Mage::app()->getStore()->getStoreId();
		$bannersCollection = Mage::getModel('mobiadmin/appsetting')->getCollection()
			->addFieldToFilter('app_code', $data['appcode'])
			->addFieldToFilter('storeid', $storeid)
			->addFieldToFilter('setting_code', 'banner_settings');

		if($bannersCollection->getSize()){
			foreach($bannersCollection as $banners){
				$banners = Mage::helper('mobiadmin')->_jsonUnserialize($banners['value']);
				if($banners){
					foreach($banners as $banner){
						if($banner['is_active'] == '1'){
		    				$bannersArray[] = $banner['url'];
		    			}
					}
				}
			}
		}
		return $bannersArray;
	}

	public function getPopupdata($data)
	{
		$popupCollection = Mage::getModel('mobiadmin/appsetting')->getCollection()
			->addFieldToFilter('app_code', $data['appcode'])
			->addFieldToFilter('setting_code', 'popup_setting');

		if($popupCollection->getSize()){
			foreach($popupCollection as $pushCollection){
				return Mage::helper('mobiadmin')->_jsonUnserialize($pushCollection['value']);
			}
		}
		else{
			return null;
		}
	}

	public function getCategoryBanners($data){
		$storeid = Mage::app()->getStore()->getStoreId();
		$categoryBanners = Mage::getModel('mobiadmin/appsetting')->getCollection()
			->addFieldToFilter('app_code', $data['appcode'])
			->addFieldToFilter('setting_code', 'category_banners')
			->addFieldToFilter('storeid', $storeid);

		if($categoryBanners->getSize()){
			foreach($categoryBanners as $categoryBanner){
				$bannerarray = Mage::helper('mobiadmin')->_jsonUnserialize($categoryBanner['value']);
				$catarray = array();
				foreach($bannerarray as $banners){
					$catid = $banners['category'];
					if($catid){
						$catarray[$catid][] = $banners;
					}					
				}
				return $catarray;
			}
		}
		else{
			return null;
		}
	}
}