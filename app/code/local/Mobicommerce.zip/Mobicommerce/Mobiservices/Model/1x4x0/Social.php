<?php

class Mobicommerce_Mobiservices_Model_1x4x0_Social extends Mobicommerce_Mobiservices_Model_Abstract {

    public function getSocialButtons($data)
    {
    	$buttons = array();
        $socialbuttons = Mage::getBlockSingleton('sociallogin/sociallogin')->getSocialButton();
        foreach($socialbuttons as $_socialbutton){
        	$buttons[] = $_socialbutton->getData();
        }
        return $buttons;
    }
}