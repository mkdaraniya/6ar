<?php
require_once Mage::getBaseDir("lib")."/rmasystem/Barcode39.php";
class Mobicommerce_Mobiservices_Model_1x4x0_Rmasystem extends Mobicommerce_Mobiservices_Model_Abstract {

    public function getRequestedOrders($data)
    {
        $customerid = Mage::getSingleton("customer/session")->getCustomerId();
        $collection = Mage::getResourceModel("rmasystem/rma_collection")->addFieldToFilter("customer_id",$customerid)->setOrder("id","DESC");

        $filter_data = Mage::getSingleton("customer/session")->getRmaFilterData();
        if($filter_data["order_id"] != "")
            $collection->addFieldToFilter("order_id",$filter_data["order_id"]);
        if($filter_data["status"] != "")
            $collection->addFieldToFilter("status",$filter_data["status"]);
        if($filter_data["rma_id"] != "")
            $collection->addFieldToFilter("id",$filter_data["rma_id"]);
        if($filter_data["date"] != "")
            $collection->addFieldToFilter("created_at",array("gt" => $filter_data["date"]." 23:59:59"));

        $sorting_data = Mage::getSingleton("customer/session")->getRmaSortingData();
        if($sorting_data["attr"] != "" && $sorting_data["direction"] != "")
            $collection->setOrder($sorting_data["attr"],$sorting_data["direction"]);

        $orders = array();
        if($collection->getSize() > 0){
            foreach ($collection as $_collection) {
                //$orders[] = $_collection->getData();
                $_order = array(
                    'id' => $_collection->getId(),
                    'increment_id' => $_collection->getIncrementId(),
                    'status_code' => $_collection->getStatus(),
                    'date_from' => date("Y-m-d g:i:s a", Mage::getModel('core/date')->timestamp($_collection->getCreatedAt()))
                    );

                switch ($_collection->getStatus()) {
                    case '1':
                        $_order['status'] = 'Pending';
                        break;

                    case '2':
                        $_order['status'] = 'Processing';
                        break;

                    case '3':
                        $_order['status'] = 'Declined';
                        break;

                    case '4':
                        $_order['status'] = 'Solved';
                        break;

                    case '5':
                        $_order['status'] = 'Cancelled';
                        break;
                    
                    default:
                        $_order['status'] = 'Unknown';
                        break;
                }

                $orders[] = $_order;
            }
        }

        $result = $this->successStatus();
        $result['data']['orders'] = $orders;
        return $result;
    }

    public function getInitData($data)
    {
        $customer_id = Mage::getSingleton("customer/session")->getCustomer()->getId();
        $allowed_status = Mage::getStoreConfig("rmasystem/rmasystem/allowed-order-status");
        if($allowed_status == "complete")
        {
            $collection = Mage::getModel("sales/order_shipment")->getCollection();
            $collection->join(array("so" => "sales/order"),"so.entity_id=main_table.order_id",array("grand_total","increment_id","created_at"), null,"left");
            $collection->addFilterToMap("created_at","so.created_at");
            $collection->addFilterToMap("customer_id","so.customer_id");
            $collection->addFilterToMap("increment_id","so.increment_id");
            $collection->addFieldToFilter("customer_id",$customer_id);
        }
        else
            $collection = Mage::getModel("sales/order")->getCollection()->addFieldToFilter("customer_id",$customer_id);

        $allowed_days = Mage::getStoreConfig("rmasystem/rmasystem/valid-days",Mage::app()->getStore());
        if($allowed_days != ""){
            $todays_second = time();
            $allowed_seconds = $allowed_days*86400;
            $past_second_from_today = $todays_second - $allowed_seconds;
            $valid_from = date("Y-m-d H:i:s",$past_second_from_today);
            $collection->addFieldToFilter("created_at",array("gteq" => $valid_from));
        }
        $filter_data = Mage::getSingleton("customer/session")->getFilterData();
        if($filter_data["order_id"] != "")
            $collection->addFieldToFilter("increment_id",$filter_data["order_id"]);
        if($filter_data["date"] != "")
            $collection->addFieldToFilter("created_at",array("gt" => $filter_data["date"]." 23:59:59"));
        if($filter_data["price"] != "")
            $collection->addFieldToFilter("grand_total",array("gteq" => $filter_data["price"]));

        $sorting_data = Mage::getSingleton("customer/session")->getSortingData();
        if($sorting_data["attr"] != "" && $sorting_data["direction"] != "")
            $collection->setOrder($sorting_data["attr"],$sorting_data["direction"]);

        $order_details = array();
        $i = 0;
        $inc = array();
        $j = 0;
        $status = array();
        $new = array();
        if($collection->getSize() > 0){
            foreach ($collection as $_collection) {
                $order_id = $_collection->getOrderId();
                $order_details[$i]['order_id'] = $order_id;
                $all_items = Mage::getModel("sales/order")->getCollection()->addFieldToFilter('entity_id',$order_id);
                foreach ($all_items as $total) {
                    $visible_item=$total->getAllVisibleItems();
                    foreach($visible_item as $it){
                        $qty_order = $it->getQtyOrdered();
                        $qty_ship = $it->getQtyShipped();
                        if($qty_order==$qty_ship){
                            $increment= Mage::getModel("sales/order")->load($it->getOrderId());
                            $inc[$i]['status']=$increment->getStatus();
                            $inc[$i]['id']=$increment->getEntityId();

                            $order_details[$i]['entity_id'] = $it->getOrderId();
                            $order_details[$i]['increment_id'] = $increment->getIncrementId();
                            $order_details[$i]['date'] = $it->getCreatedAt();
                            $order_details[$i]['date_from'] = date("Y-m-d g:i:s a", Mage::getModel('core/date')->timestamp($it->getCreatedAt()));
                            $order_details[$i]['grand_total'] = $it->getRowTotalInclTax();
                            $order_details[$i]['customer_id'] = $increment->getCustomerId();
                        }
                    }
                    $i++;
                }
            }
        }
       
        $order_details = array_unique($order_details, SORT_REGULAR);
        $allowed_status = Mage::getStoreConfig("rmasystem/rmasystem/allowed-order-status");

        $packageConditions = array(
            array(
                'id' => 0,
                'value' => 'Open'
                ),
            array(
                'id' => 1,
                'value' => 'Packed'
                ),
            );

        $resolutionTypes = array(
            array(
                'id' => 0,
                'value' => 'Refund'
                ),
            array(
                'id' => 1,
                'value' => 'Exchange'
                ),
            );

        $productDeliveryStatus = array(
            array(
                'id' => 0,
                'value' => 'Not Delivered Yet'
                ),
            array(
                'id' => 1,
                'value' => 'Delivered'
                ),
            );

        $returnReason = array();
        $reasonCollection = Mage::getModel("rmasystem/reason")->getCollection()->addFieldToFilter("status", 1);
        if($reasonCollection->getSize() > 0){
            foreach($reasonCollection as $_collection){
                $returnReason[] = array(
                    'id' => $_collection->getId(),
                    'value' => $_collection->getReason()
                    );
            }    
        }
        
        $returnPolicy = Mage::getStoreConfig("rmasystem/rmasystem/policy");

        $result = $this->successStatus();
        $result['data']['orders'] = $order_details;
        $result['data']['packageConditions'] = $packageConditions;
        $result['data']['resolutionTypes'] = $resolutionTypes;
        $result['data']['productDeliveryStatus'] = $productDeliveryStatus;
        $result['data']['returnPolicy'] = $returnPolicy;
        $result['data']['returnReason'] = $returnReason;

        return $result;
    }

    public function getOrderDetails($data)
    {
        $order_id = isset($data['order_id']) ? $data['order_id'] : null;
        $order_details = array();
        
        $all_items = Mage::getModel("sales/order")->load($order_id)->getAllVisibleItems();
        foreach($all_items as $item){
            $url = Mage::getModel("catalog/product")->getCollection()->addFieldToFilter("entity_id",$item->getProductId())->getFirstItem()->getProductUrl();

            $qty_order = $item->getQtyOrdered();
            $qty_ship = $item->getQtyShipped();
            if($qty_order == $qty_ship){
                array_push($order_details, array(
                    "url"        => $url,
                    "name"       => $item->getName(),
                    "sku"        => $item->getSku(),
                    "qty"        => intval($item->getQtyOrdered()),
                    "itemid"     => $item->getItemId(),
                    "product_id" =>$item->getProductId()
                    ));
            }
        }

        $result = $this->successStatus();
        $result['data']['order_details'] = $order_details;
        return $result;
    }

    public function submitReturnRequest($data)
    {
        $error = false;
        if($data){
            if(empty($data['order_id']) || empty($data['increment_id']))
                return $this->errorStatus(Mage::helper('core')->__("Unable to save"));
            
            $file = new Varien_Io_File();
            $customer_id = Mage::getSingleton("customer/session")->getId();
            $rma = Mage::getModel("rmasystem/rma")
                    ->setOrderId($data["order_id"])
                    ->setGroup("customer")
                    ->setIncrementId($data["increment_id"])
                    ->setResolutionType($data["resolution_type"])
                    ->setPackageCondition($data["package_condition"])
                    ->setCustomerId($customer_id)
                    ->setAdditionalInfo($data["additional_info"])
                    ->setCustomerDeliveryStatus($data["customer_delivery_status"])
                    ->setCustomerConsignmentNo($data["customer_consignment_no"])
                    ->setStatus(1)
                    ->setCreatedAt(time());
            $last_rma_id = $rma->save()->getId();
            $image_array = array();

            if(isset($data['image']) && !empty($data['image'])){
                $path = Mage::getBaseDir("media").DS."RMA".DS.$last_rma_id.DS;
                $file->mkdir($path);
                $new_image_name = time().$data['image'];
                rename(Mage::getBaseDir('media') . DS . '/mobi_commerce/mobileuploads/'.$data['image'],$path.$new_image_name);
                $image_array[$new_image_name] = $data['image'];
            }

            $ext_array = array("jpg","JPG","jpeg","JPEG","gif","GIF","png","PNG","bmp","BMP");
            if($_FILES["related_images"]["tmp_name"][0] != ""){
                $path = Mage::getBaseDir("media").DS."RMA".DS.$last_rma_id.DS;
                $file->mkdir($path);
                foreach($_FILES["related_images"]["tmp_name"] as $key => $value){
                    $ext = explode(".",$_FILES["related_images"]["name"][$key]);
                    if(in_array(end($ext), $ext_array)){
                        $new_image_name = time().$_FILES["related_images"]["name"][$key];
                        move_uploaded_file($value, $path.$new_image_name);
                        $image_array[$new_image_name] = $_FILES["related_images"]["name"][$key];
                    }
                    else
                        $error = true;
                }
            }
            Mage::getModel("rmasystem/rma")->load($last_rma_id)->setImages(serialize($image_array))->save();
            foreach($data["item_checked"] as $key => $item) {
                Mage::getModel("rmasystem/items")
                    ->setRmaId($last_rma_id)
                    ->setItemId($key)
                    ->setReasonId($data["item_reason"][$key])
                    ->setQty($data["return_item"][$key])
                    ->save();
            }
            $bar_code = new Barcode39($data["increment_id"]);
            $bar_code->barcode_text_size = 5; 
            $bar_code->barcode_bar_thick = 4; 
            $bar_code->barcode_bar_thin = 2;
            $bar_code_path = Mage::getBaseDir("media")."/RMA/Barcodes/";
            $file->mkdir($bar_code_path);
            $bar_code->draw($bar_code_path.$last_rma_id.".gif");
            if($last_rma_id > 0)
                Mage::getModel("rmasystem/mails")->NewRma($data,$last_rma_id,$rma->getGroup());
            /*
            if($error == true)
                Mage::getSingleton("core/session")->addNotice($this->__("All files may not be uploaded"));
            */
            return $this->successStatus(Mage::helper('core')->__("RMA Saved Successfully"));
        }
        else{
            return $this->errorStatus(Mage::helper('core')->__("Unable to save"));
        }
    }
}