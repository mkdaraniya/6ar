<?php

class Mobicommerce_Mobiservices_Model_1x3x1_External extends Mobicommerce_Mobiservices_Model_Abstract
{
    public function __install102ScriptAction()
    {
        
    }
}