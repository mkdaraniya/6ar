<?php

class Mobicommerce_Mobiservices_RmasystemController extends Mobicommerce_Mobiservices_Controller_Action {

    public function getRequestedOrdersAction()
    {
        $data = $this->getData();
        $information = Mage::getModel(Mage::getBlockSingleton('mobiservices/connector')->_getConnectorModel('mobiservices/rmasystem'))->getRequestedOrders($data);
        $this->printResult($information);
    }

    public function getInitDataAction()
    {
        $data = $this->getData();
        $information = Mage::getModel(Mage::getBlockSingleton('mobiservices/connector')->_getConnectorModel('mobiservices/rmasystem'))->getInitData($data);
        $this->printResult($information);
    }

    public function getOrderDetailsAction()
    {
    	$data = $this->getData();
        $information = Mage::getModel(Mage::getBlockSingleton('mobiservices/connector')->_getConnectorModel('mobiservices/rmasystem'))->getorderDetails($data);
        $this->printResult($information);
    }

    public function submitReturnRequestAction()
    {
    	$data = $this->getData();
        $information = Mage::getModel(Mage::getBlockSingleton('mobiservices/connector')->_getConnectorModel('mobiservices/rmasystem'))->submitReturnRequest($data);
        $this->printResult($information);
    }
}