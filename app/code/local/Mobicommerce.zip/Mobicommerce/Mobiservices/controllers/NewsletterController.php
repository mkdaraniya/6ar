<?php

class Mobicommerce_Mobiservices_NewsletterController extends Mobicommerce_Mobiservices_Controller_Action {

	public function saveAction()
	{
		$data = $this->getData();
		$information = Mage::getModel(Mage::getBlockSingleton('mobiservices/connector')->_getConnectorModel('mobiservices/newsletter'))->save($data);
		$this->printResult($information);
	}
}