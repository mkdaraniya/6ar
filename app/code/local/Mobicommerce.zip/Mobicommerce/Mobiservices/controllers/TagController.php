<?php

class Mobicommerce_Mobiservices_TagController extends Mobicommerce_Mobiservices_Controller_Action {

    public function addProductTagAction()
    {
        $data = $this->getData();
        $information = Mage::getModel(Mage::getBlockSingleton('mobiservices/connector')->_getConnectorModel('mobiservices/tag'))->addProductTag($data);
        $this->printResult($information);
    }
}