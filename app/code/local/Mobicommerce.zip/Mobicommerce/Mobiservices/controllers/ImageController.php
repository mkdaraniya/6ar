<?php

class Mobicommerce_Mobiservices_ImageController extends Mobicommerce_Mobiservices_Controller_Action {

    public function uploadAction()
    {
        if(isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])){
        	$uploader = new Varien_File_Uploader('file');
		    $uploader->setAllowRenameFiles(true);
		    $uploader->setAllowCreateFolders(true);
		    $path = Mage::getBaseDir('media') . DS . '/mobi_commerce/mobileuploads';           
		    $uploader->save($path, $_FILES['file']['name']);
		    echo $uploader->getUploadedFileName();exit;
        }
        echo 'Oops_something_wrong_happened';
    }   
}