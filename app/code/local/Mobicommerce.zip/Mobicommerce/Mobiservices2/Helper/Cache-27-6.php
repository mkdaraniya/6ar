<?php
class Mobicommerce_Mobiservices2_Helper_Cache extends Mage_Core_Helper_Abstract {

    public function createCacheDir($appcode)
    {
        $store = Mage::app()->getStore()->getId();
        $currency_code = Mage::app()->getStore()->getCurrentCurrencyCode();
        $path = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'cache';
        if(!file_exists($path))
            mkdir($path, 0755, TRUE);

        if(!file_exists($path.DS.'store'))
            mkdir($path.DS.'store', 0755, TRUE);

        if(!file_exists($path.DS.'store'.DS.$store))
            mkdir($path.DS.'store'.DS.$store, 0755, TRUE);

        $cachepath_root = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'cache';
        $cachepath_language = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache'.DS.'language';

        if(!file_exists(Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v')){
            @mkdir(Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v', 0755);
        }
        if(!file_exists(Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion())){
            @mkdir(Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion(), 0755);
        }
        if(!file_exists(Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache')){
            @mkdir(Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache', 0755);
        }
        if(!file_exists(Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache'.DS.'store')){
            @mkdir(Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache'.DS.'store', 0755);
        }

        $cachepath_store = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'cache'.DS.'store'.DS.$store;
        $cachepath_store_v = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache'.DS.'store'.DS.$store;
        $cachepath_store_currency = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'cache'.DS.'store'.DS.$store.DS.$currency_code;
        $cachepath_catproducts = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'cache'.DS.'store'.DS.$store.DS.$currency_code.DS.'category_products';
        $cachepath_catwidgets = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache'.DS.'store'.DS.$store.DS.$currency_code.DS.'category_widgets';

        $data['cachepath_root']           = $cachepath_root;
        $data['cachepath_store']          = $cachepath_store;
        $data['cachepath_store_v']        = $cachepath_store_v;
        $data['cachepath_store_currency'] = $cachepath_store_currency;
        $data['cachepath_language']       = $cachepath_language;
        $data['cachepath_catproducts']    = $cachepath_catproducts;
        $data['cachepath_catwidgets']     = $cachepath_catwidgets;
        foreach($data as $key => $value){
            if(!file_exists($value)){
                @mkdir($value, 0755);
            }
        }
        return $data;
    }

    public function flushAllCache()
    {
        $collection = Mage::getModel('mobiadmin2/applications')->getCollection();

        $paths = array();
        $paths[] = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache';

        if($collection->getSize() > 0){
            foreach($collection as $_collection){
                $paths[] = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$_collection->getAppCode().DS.'cache';
            }
        }

        foreach($paths as $path){
            if(file_exists($path)){
                Mage::helper('mobiservices2/mobicommerce')->rrmdir($path);
            }
        }
    }

    /**
     * This function is used to flush and regenerate cache data
     */
    public function flushAndRegenerateAllCache()
    {
        $this->flushAllCache();
    }

    /**
     * This function is used to generate cache file for specific type of caching.
     */
    public function setCacheData($type, $appcode, $params = null)
    {
        if(empty($appcode))
            return false;

        $paths = $this->createCacheDir($appcode);
        $store = Mage::app()->getStore()->getId();

        switch ($type) {
            case 'homepage_widgets':
                $data = $this->_getWidgets($appcode);
                file_put_contents($paths['cachepath_store_currency'].DS.'homepage_widgets.txt', serialize($data));
                //echo '<pre>';print_r($data);exit;
                break;
            case 'category':
                $rootCategoryId = Mage::app()->getStore($store)->getRootCategoryId();
                $tree = Mage::getResourceSingleton('catalog/category_tree')->load();
                $root = $tree->getNodeById($rootCategoryId);
                if($root && $root->getId() == 1) { 
                    $root->setName(Mage::helper('catalog')->__('Root')); 
                }
                $collection = Mage::getModel('catalog/category')->getCollection() 
                    ->addAttributeToSelect('name') 
                    ->addAttributeToFilter('is_active','1')
                    //->addAttributeToFilter('display_mode',array('nlike'=>'PAGE'))
                    //->setLoadProductCount(true)
                    //->setProductStoreId($store)
                    ->addAttributeToFilter('include_in_menu','1');

                $tree->addCollectionData($collection, true);
                $data = $this->_nodeToArray($root);
                $data = $this->_make_tree_to_list($data['children']);
                $data = $this->_remove_category_children($data);
                $data = $this->_assignCategoryThumbnail($data);
                file_put_contents($paths['cachepath_store_v'].DS.'category.txt', serialize($data));
                //echo '<pre>';print_r($data);exit;
                break;
            case 'category_products':
                if(isset($params['categoryId']) && !empty($params['categoryId'])){
                    $category = Mage::getModel("catalog/category")->load($params['categoryId']);
                    $pCollection = $category->getProductCollection();
                    $pCollection->addAttributeToSelect(Mage::getSingleton('catalog/config')->getProductAttributes())
                        ->addAttributeToFilter('status', '1')
                        ->addAttributeToFilter('visibility', '4')
                        ->setStoreId($store)
                        ->addMinimalPrice()
                        ->addFinalPrice();

                    $advanceSettings = $this->_getAdvanceSettings($appcode);

                    $enableOutofStockItems = false;
                    if(isset($advanceSettings['miscellaneous']['enable_outofstock']) && !empty($advanceSettings['miscellaneous']['enable_outofstock'])){
                        $enableOutofStockItems = true;
                    }

                    if(!$enableOutofStockItems){
                        Mage::getSingleton('cataloginventory/stock')
                            ->addInStockFilterToCollection($pCollection);
                    }

                    if(isset($advanceSettings['productlist']['default_sorting']) && !empty($advanceSettings['productlist']['default_sorting'])){
                        switch ($advanceSettings['productlist']['default_sorting']) {
                            case "position":
                                $pCollection->setOrder('position', 'ASC');
                                break;
                            case "price-l-h": 
                                $pCollection->setOrder('price', 'asc');
                                break;
                            case "price-h-l":
                                $pCollection->setOrder('price', 'desc');
                                break;
                            case "rating-h-l":
                                $pCollection->joinField('rating_score', 
                                       'review_entity_summary', 
                                       'rating_summary', 
                                       'entity_pk_value=entity_id', 
                                       array('entity_type'=>1, 'store_id'=> Mage::app()->getStore()->getId()),
                                       'left'
                                );
                                $pCollection->setOrder('rating_score', 'desc');
                                break;
                            case "name-a-z":
                                $pCollection->setOrder('name', 'asc');
                                break;
                            case "name-z-a":
                                $pCollection->setOrder('name', 'desc');
                                break;
                            case "newest":
                                $pCollection->setOrder('entity_id', 'desc');
                                break;
                            default: 
                                $pCollection->setOrder('ordered_qty', 'asc');
                                break;
                        }
                    }
                    $product_count = $pCollection->getSize();
                    //echo '<pre>';print_r($advanceSettings);exit;
                    $pCollection->getSelect()->limit(30);

                    /* for category filters */
                    $filter = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/catalog_catalog'))->_getCategoryFilters($params['categoryId']);
                    /* for category filters - upto here */
                    
                    $data = array(
                        'filter'        => $filter,
                        'products'      => array(),
                        'product_count' => $product_count
                        );
                    if($pCollection->getSize() > 0){
                        foreach($pCollection as $_collection){
                            $_product = array(
                                'product_id'              => $_collection->getId(),
                                'entity_id'               => $_collection->getId(),
                                'name'                    => $_collection->getName(),
                                'type_id'                 => $_collection->getTypeId(),
                                'price'                   => Mage::helper('mobiservices2/mobicommerce')->getProductPriceByCurrency($_collection->getPrice()),
                                'special_price'           => Mage::helper('mobiservices2/mobicommerce')->getProductPriceByCurrency($_collection->getFinalPrice()),
                                'stock_status'            => $stock,
                                'product_reviews'         => Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/catalog_catalog'))->_getProductReviews($_collection->getId(), $store),
                                'product_small_image_url' => NULL,
                                'product_image_url'       => NULL
                                );

                            try{
                                $_product['product_small_image_url'] = Mage::helper('catalog/image')->init($_collection, 'small_image')->__toString();
                                $_product['product_image_url'] = $_product['product_small_image_url'];
                            }
                            catch(Exception $e){}
                            
                            $data['products'][] = $_product;
                        }
                    }
                    file_put_contents($paths['cachepath_catproducts'].DS.$params['categoryId'].'.txt', serialize($data));
                    //echo '<pre>';print_r($data);exit;
                }
                break;
            case 'category_widgets':
                if(isset($params['categoryId']) && !empty($params['categoryId'])){
                    $data = $this->_getWidgets($appcode, $params['categoryId']);
                    file_put_contents($paths['cachepath_catwidgets'].DS.$params['categoryId'].'.txt', serialize($data));
                    //echo '<pre>';print_r($data);exit;
                }
                break;
            case 'social_login':
                $data = $this->_getSocialLogin();
                file_put_contents($paths['cachepath_store_v'].DS.'social_login.txt', serialize($data));
                //echo '<pre>';print_r($data);exit;
                break;
            case 'advance_settings':
                $data = $this->_getAdvanceSettings($appcode);
                file_put_contents($paths['cachepath_store'].DS.'advance_settings.txt', serialize($data));
                //echo '<pre>';print_r($data);exit;
                break;
            case 'googleanalytics':
                $data = $this->_getAnalyticsSettings($appcode);
                file_put_contents($paths['cachepath_root'].DS.'googleanalytics.txt', serialize($data));
                //echo '<pre>';print_r($data);exit;
                break;
            case 'cms':
                $collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
                $collection
                    ->addFieldToFilter('app_code', $appcode)
                    ->addFieldToFilter('setting_code', 'cms_settings')
                    ->addFieldToFilter('storeid', $store);
                if($collection->getSize() > 0){
                    $data = @unserialize($collection->getFirstItem()->getValue());

                    $cmsCollection = Mage::getModel('cms/page')->getCollection()
                        ->addFieldToFilter('is_active', 1);
                    $allcms = array();
                    if($cmsCollection->getSize()){
                        foreach($cmsCollection as $_collection){
                            $allcms[$_collection->getPageId()] = $_collection->getData();
                        }
                    }
                    //echo '<pre>';print_r($allcms);exit;
                    $cms = array();
                    foreach($data['cms_pages'] as $key => $value){
                        if(isset($allcms[$value['id']])){
                            $cms[] = array(
                                'page_id' => $allcms[$value['id']]['page_id'],
                                'title'   => $allcms[$value['id']]['title'],
                                'content' => $allcms[$value['id']]['content']
                                );
                        }
                    }
                    $data['cms_pages'] = $cms;
                    file_put_contents($paths['cachepath_store'].DS.'cms.txt', serialize($data));
                    //echo '<pre>';print_r($data);exit;
                }
                break;
            case 'language':
                //if(is_numeric($store))
                //as this issue identified in vamas app for value 1
                if(is_numeric($store) || $store === true)
                    $locale = Mage::getStoreConfig('general/locale/code', $store);
                else
                    $locale = $store;

                $language = Mage::helper('mobiadmin2')->getLanguageData($locale);
                $data = array();
                foreach($language as $key => $label){
                    $data[$key] = array(
                        'text' => $label['mm_text'],
                        );
                }
                file_put_contents($paths['cachepath_language'].DS.$locale.'.txt', serialize($data));
                //echo '<pre>';print_r($language);exit;
                break;
            case 'appinfo':
                $collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
                $collection
                    ->addFieldToFilter('app_code', $appcode)
                    ->addFieldToFilter('setting_code', 'appinfo');
                if($collection->getSize() > 0){
                    $data = @unserialize($collection->getFirstItem()->getValue());
                    file_put_contents($paths['cachepath_root'].DS.'appinfo.txt', serialize($data));
                    //echo '<pre>';print_r($data);exit;
                }
                break;
            case 'pushsettings':
                $collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
                $collection
                    ->addFieldToFilter('app_code', $appcode)
                    ->addFieldToFilter('setting_code', 'push_notification');
                if($collection->getSize() > 0){
                    $data = @unserialize($collection->getFirstItem()->getValue());
                    file_put_contents($paths['cachepath_root'].DS.'pushsettings.txt', serialize($data));
                    //echo '<pre>';print_r($data);exit;
                }
                break;
            case 'storeinfo':
                $currencyCode = Mage::app()->getStore($store)->getCurrentCurrencyCode();
                $data = array(
                    'store_id'          => Mage::app()->getStore($store)->getId(),
                    'store_name'        => Mage::app()->getStore($store)->getName(),
                    'store_code'        => Mage::app()->getStore($store)->getCode(),
                    'locale_identifier' => Mage::getStoreConfig('general/locale/code', $store),
                    'root_category_id'  => Mage::app()->getStore($store)->getRootCategoryId(),
                    'currency_name'     => Mage::app()->getLocale($store)->currency($currencyCode)->getName(),
                    'currency_symbol'   => Mage::app()->getLocale($store)->currency($currencyCode)->getSymbol(),
                    'currency_code'     => Mage::app()->getStore($store)->getCurrentCurrencyCode(),
                    'storeConfig'       => array(
                        'web' => array(
                            'add_store_code_to_urls' => Mage::getStoreConfig('web/url/use_store', $store),
                            ),
                        'storelocator' => array(
                            'enabled'          => Mage::getStoreConfig('mobistorelocator2/storelocator2/active', $store),
                            'search_by_region' => Mage::getStoreConfig('mobistorelocator2/storelocator2/search_region', $store),
                            'unit_of_distance' => Mage::getStoreConfig('mobistorelocator2/storelocator2/unit_measurement', $store),
                            'storezoom'        => Mage::getStoreConfig('mobistorelocator2/storelocator2/storezoom', $store),
                            'storerating'      => Mage::getStoreConfig('mobistorelocator2/storelocator2/storerating', $store),
                            )
                        )
                    );

                if(empty($data['currency_symbol'])){
                    $data['currency_symbol'] = $data['currency_code'];
                }
                file_put_contents($paths['cachepath_store_currency'].DS.'storeinfo.txt', serialize($data));
                //echo '<pre>';print_r($data);exit;
                break;
            case 'country':
                $data = array();        
                $country_default = Mage::getStoreConfig('general/country/default');
                $countries = Mage::getResourceModel('directory/country_collection')->loadByStore();
                $cache = null;
                foreach ($countries as $country){
                    $states = Mage::getModel('directory/country')->loadByCode($country->getId())->getRegions();
                    $list = array();
                    if($states){
                        foreach ($states as $state) {
                            $list[] = array(
                                'region_id' => $state->getRegionId(),
                                'name'      => $state->getName(),
                                'code'      => $state->getCode(),
                            );
                        }
                    }
                    if ($country_default == $country->getId()){
                        $cache = array(
                            'iso2'   => $country->getId(),
                            'name'   => $country->getName(),
                            'states' => $list,
                        );
                    }
                    else{
                        $data[] = array(
                            'iso2'   => $country->getId(),
                            'name'   => $country->getName(),
                            'states' => $list,
                        );   
                    }            
                }
                if(!empty($data)){
                    $iso2 = array();
                    $name = array();
                    foreach ($data as $key => $row){
                        $iso2[$key]  = $row['iso2'];
                        $name[$key] = $row['name'];
                    }
                    array_multisort($name, SORT_ASC, $iso2, SORT_DESC, $data);
                }

                if($cache){
                    array_unshift($data, $cache);
                }        
                file_put_contents($paths['cachepath_store'].DS.'country.txt', serialize($data));
                break;
            case 'stores':
                $data = array();
                $groupId = Mage::app()->getStore($store)->getGroupId();
                $isMultiStoreView = Mage::helper('mobiadmin2')->isMultiStoreView();
                if($isMultiStoreView){
                    $storeViews = Mage::app()->getStores();
                }
                else{
                    $storeViews = Mage::app()->getGroup($groupId)->getStores();
                }

                foreach($storeViews as $_store){
                    $s = $_store->getData(); 
                    $s['url'] = $_store->getUrl(); 
                    if($_store->getStoreId() == Mage::app()->getStore()->getStoreId()){
                        $codes = Mage::app()->getStore()->getAvailableCurrencyCodes(true);
                        $available_currency_codes = Mage::getModel('core/config_data')
                            ->getCollection()
                            ->addFieldToFilter('path','currency/options/allow')
                            ->addFieldToFilter('scope_id', $store)
                            ->getData();
                        if(isset($available_currency_codes[0])){
                            $available_currency_codes = $available_currency_codes[0];
                            if(isset($available_currency_codes['value'])){
                                $s['available_currency_codes'] = explode(',', $available_currency_codes['value']);
                            }
                        }
                        else{
                            $codes = Mage::app()->getStore()->getAvailableCurrencyCodes(true);
                            if(!empty($codes)){
                                $s['available_currency_codes'] = $codes;
                            }
                        }
                    }
                    $data[] = $s;
                }   
                file_put_contents($paths['cachepath_store_v'].DS.'stores.txt', serialize($data));
               
                break;
            default:
                # code...
                break;
        }

        return $data;
    }

    /**
     * This function is used to get cache data
     * If file does not exists, then it will create cache file.
     */
    public function getCacheData($type, $appcode, $params = null)
    {
        if(empty($appcode))
            return false;

        $_isMobiCacheEnabled = Mage::getBlockSingleton('mobiservices2/connector')->isMobiCacheEnabled();
        if(!$_isMobiCacheEnabled){
            return $this->setCacheData($type, $appcode, $params);
        }

        $paths = $this->createCacheDir($appcode);
        switch ($type) {
            case 'homepage_widgets':
                if(!file_exists($paths['cachepath_store_currency'].DS.'homepage_widgets.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_store_currency'].DS.'homepage_widgets.txt'));
                break;
            case 'category':
                if(!file_exists($paths['cachepath_store_v'].DS.'category.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_store_v'].DS.'category.txt'));
                break;
            case 'category_products':
                if(!file_exists($paths['cachepath_catproducts'].DS.$params['categoryId'].'.txt')){
                    $this->setCacheData($type, $appcode, $params);
                }
                return @unserialize(file_get_contents($paths['cachepath_catproducts'].DS.$params['categoryId'].'.txt'));
                break;
            case 'category_widgets':
                if(!file_exists($paths['cachepath_catwidgets'].DS.$params['categoryId'].'.txt')){
                    $this->setCacheData($type, $appcode, $params);
                }
                return @unserialize(file_get_contents($paths['cachepath_catwidgets'].DS.$params['categoryId'].'.txt'));
                break;
            case 'social_login':
                if(!file_exists($paths['cachepath_store_v'].DS.'social_login.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_store_v'].DS.'social_login.txt'));
                break;
            case 'advance_settings':
                if(!file_exists($paths['cachepath_store'].DS.'advance_settings.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_store'].DS.'advance_settings.txt'));
                break;
            case 'googleanalytics':
                if(!file_exists($paths['cachepath_root'].DS.'googleanalytics.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_root'].DS.'googleanalytics.txt'));
                break;
            case 'cms':
                if(!file_exists($paths['cachepath_store'].DS.'cms.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_store'].DS.'cms.txt'));
                break;
            case 'language':
                $locale = Mage::getStoreConfig('general/locale/code', $store);
                if(!file_exists($paths['cachepath_language'].DS.$locale.'.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_language'].DS.$locale.'.txt'));
                break;
            case 'appinfo':
                if(!file_exists($paths['cachepath_root'].DS.'appinfo.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_root'].DS.'appinfo.txt'));
                break;
            case 'pushsettings':
                if(!file_exists($paths['cachepath_root'].DS.'pushsettings.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_root'].DS.'pushsettings.txt'));
                break;
            case 'storeinfo':
                if(!file_exists($paths['cachepath_store_currency'].DS.'storeinfo.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_store_currency'].DS.'storeinfo.txt'));
                break;
            case 'country':
                if(!file_exists($paths['cachepath_store'].DS.'country.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_store'].DS.'country.txt'));
                break;
            case 'stores':
                if(!file_exists($paths['cachepath_store_v'].DS.'stores.txt')){
                    $this->setCacheData($type, $appcode);
                }
                return @unserialize(file_get_contents($paths['cachepath_store_v'].DS.'stores.txt'));
                break;
            default:
                return null;
                break;
        }
    }

    /**
     * This function is used to set product detail cache
     */
    public function setProductCache($productId)
    {
        $store = Mage::app()->getStore()->getId();
        $currency_code = Mage::app()->getStore()->getCurrentCurrencyCode();
        $path = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache'.DS.'store'.DS.$store.DS.$currency_code.DS.'product';
        @mkdir($path, 0755, TRUE);

        $product = Mage::getModel('catalog/product')->setStoreId($store)->load($productId);
        if($product->getId()){
            $option = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/catalog_catalog'))->_getAllProductOptions($product);
            $prices = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/catalog_catalog'))->_productPrices($product);

            $images = array();
            foreach ($product->getMediaGallery('images') as $image) {
                if($image['disabled']){
                    continue;
                }
                $images[] = array(
                    'full_image_url' => Mage::helper('catalog/image')->init($product, 'thumbnail',$image['file'])->__toString(),
                    'id'             => isset($image['value_id']) ? $image['value_id'] : null,
                    'position'       => $image['position'],
                    'label'          => $image['label'],
                    );
            }
            if(empty($images)){
                try{
                    $images[] = array(
                        'full_image_url' => Mage::helper('catalog/image')->init($product, 'image')->__toString(),
                        'id'             => '0',
                        'position'       => '1',
                        'label'          => 'Base Image',
                        );
                }
                catch(Exception $e){}
            }

            if($product->getTypeId() == 'configurable'){
                $configurable_images = array();
                $associated_products = $product->loadByAttribute('sku', $product->getSku())->getTypeInstance()->getUsedProducts();
                if (count($associated_products) > 0) {
                    foreach($associated_products as $key => $ap){
                        if($key > 0)
                            continue;
                        $ap = Mage::getModel('catalog/product')->setStoreId($store)->load($ap->getId());
                        foreach ($ap->getMediaGallery('images') as $image) {
                            if($image['disabled']){
                                continue;
                            }
                            $configurable_images[] = array(
                                'full_image_url' => Mage::helper('catalog/image')->init($product, 'thumbnail',$image['file'])->__toString(),
                                'id'             => isset($image['value_id']) ? $image['value_id'] : null,
                                'position'       => $image['position'],
                                'label'          => $image['label'],
                                );
                       }
                    }
                }

                if(!empty($configurable_images)){
                    $images = $configurable_images;
                }
            }

            $stock = true;
            if (version_compare(Mage::getVersion(), '1.4.0.1', '=') === true) {
                if (!$product->isSaleable()) $stock = false;
            }

            $inventory = Mage::getModel('cataloginventory/stock_item')->loadByProduct($product);
            $productInfo = array(
                'product_id'            => $product->getId(),
                'name'                  => $product->getName(),
                'url'                   => $product->getProductUrl(),
                'type'                  => $product->getTypeId(),
                'attributeSetName'      => Mage::getModel("eav/entity_attribute_set")->load($product->getAttributeSetId())->getAttributeSetName(),
                'price'                 => Mage::helper('mobiservices2/mobicommerce')->getProductPriceByCurrency($product->getPrice()),
                'special_price'         => Mage::helper('mobiservices2/mobicommerce')->getProductPriceByCurrency($product->getFinalPrice()),
                'description'           => Mage::helper('catalog/output')->productAttribute($product, $product->getDescription(), 'description'),
                'short_description'     => Mage::helper('catalog/output')->productAttribute($product, $product->getShortDescription(), 'short_description'),
                'max_qty'               => (int) $inventory->getQty(),
                'qty_increments'        => (int) $inventory->getQtyIncrements(),
                'product_images'        => $images,
                'product_thumbnail_url' => NULL,
                'stock_status'          => $stock,
                'options'               => $option,
                'product_reviews'       => Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/catalog_catalog'))->_getProductReviews($productId, $store),
                //'tags'                  => Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/catalog_catalog'))->_getProductTags($product, $store)
            );

            try{
                $productInfo['product_thumbnail_url'] = Mage::helper('catalog/image')->init($product, 'thumbnail')->__toString();
            }
            catch(Exception $e){}

            if ($prices){
                $productInfo = array_merge($productInfo, $prices);
            }

            $productInfo = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/custom'))->getCustomProductDetailFields($product, $productInfo);

            $productInfo['relatedProducts'] = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/catalog_catalog'))->getRelatedProducts($product, $store);
            $productInfo['ratingOptions'] = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/review'))->_getRatingOptions(array("product_id" => $productId), $store);

            file_put_contents($path.DS.$productId.'.txt', serialize($productInfo));
            //echo '<pre>';print_r($productInfo);exit;
            return $productInfo;
        }
        return null;
    }

    /**
     * This function is used to get product detail cache
     */
    public function getProductCache($productId)
    {
        $store = Mage::app()->getStore()->getId();
        $currency_code = Mage::app()->getStore()->getCurrentCurrencyCode();
        $_isMobiCacheEnabled = Mage::getBlockSingleton('mobiservices2/connector')->isMobiCacheEnabled();
        if(!$_isMobiCacheEnabled){
            return $this->setProductCache($productId);
        }
        
        $path = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'cache'.DS.'store'.DS.$store.DS.$currency_code.DS.'product';
        if(!file_exists($path.DS.$productId.'.txt')){
            $this->setProductCache($productId);
        }
        return @unserialize(file_get_contents($path.DS.$productId.'.txt'));
    }

    public function clearProductCache($productId = null)
    {
        $this->flushAllCache();
        return;
    }

    public function clearCmsCache()
    {
        $this->flushAllCache();
        return;
    }

    /**
     * This function will be used as hook.
     * When there is certain change in either category or products,
     * we will destroy cache file of that product'c category or that category file
     * depend on either product is changed or category is changed
     */
    public function clearCategoryProductsCache($params = null)
    {
        $this->flushAllCache();
        return;
    }

    protected function _nodeToArray(Varien_Data_Tree_Node $node) 
    { 
        $result = array();
        if(!$node)
            return $result;
        
        $category = Mage::getModel('catalog/category')->load($node->getId());
        $result['category_id']    = $node->getId();
        $result['parent_id']      = $node->getParentId();
        $result['name']           = $node->getName();
        $result['is_active']      = $node->getIsActive();
        $result['level']          = $node->getLevel();
        //$result['products_count'] = $node->getProductCount();
        $result['products_count'] = $category->getProductCount();
        $result['display_mode']   = $category->getDisplayMode();
        $result['thumbnail_url']  = null;
        if($image = $category->getThumbnail()){
            $result['thumbnail_url']  = Mage::getBaseUrl('media').'catalog/category/'.$image;
        }
        if(in_array($result['display_mode'], array('PAGE'))){
            $result['description'] = $category->getDescription();
            $result['cmsblock_html'] = Mage::app()->getLayout()->createBlock('cms/block')->setBlockId($category->getLandingPage())->toHtml();
        }

        foreach ($node->getChildren() as $child) {
            $result['children'][] = $this->_nodeToArray($child); 
        }

        return $result; 
    }

    protected function _make_tree_to_list($categories = null, $category_result = array())
    {
        if(!empty($categories)){
            foreach($categories as $category){
                $category_result[] = $category;
                if(isset($category['children']) && count($category['children']) > 0){
                    $category_result = $this->_make_tree_to_list($category['children'], $category_result);
                }
            }
        }
        return $category_result;
    }

    protected function _remove_category_children($categories = array())
    {
        $_category_array = array();
        if(!empty($categories)){
            foreach($categories as $key => $category){
                $categories[$key]['children'] = isset($category['children']) ? count($category['children']) : 0;
                //if($category['products_count'] > 0 || $categories[$key]['children'] > 0){
                    $_category_array[] = $categories[$key];
                //}
            }
        }
        return $_category_array;
    }

    protected function _assignCategoryThumbnail($categories)
    {
        $allcategories = array();
        $categoryIds = array();
        if(!empty($categories)){
            foreach ($categories as $key => $value) {
                $allcategories[$value['category_id']] = $value;
                $categoryIds[] = $value['category_id'];
            }
        }

        $collection = Mage::getModel('mobiadmin2/categoryicon')->getCollection();
        $collection->addFieldToFilter('mci_category_id', array('in' => $categoryIds));
        if($collection->getSize() > 0){
            foreach($collection as $_collection){
                $allcategories[$_collection->getMciCategoryId()]['thumbnail_url'] = Mage::getBaseUrl('media').'mobi_commerce/category/'.$_collection->getMciThumbnail();
            }
        }

        $collection = Mage::getModel('mobiadmin2/categorywidget')->getCollection();
        $collection->addFieldToFilter('widget_category_id', array('in' => $categoryIds));
        if($collection->getSize() > 0){
            foreach($collection as $_collection){
                $allcategories[$_collection->getWidgetCategoryId()]['has_widgets'] = true;
            }
        }
        return array_values($allcategories);
    }

    public function _getAdvanceSettings($appcode)
    {
        $collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
        $collection->addFieldToFilter('app_code', $appcode)
            ->addFieldToFilter('setting_code', 'advance_settings');

        if(Mage::helper('mobiadmin2')->isMultiStoreView()){
            $collection->addFieldToFilter('storeid', Mage::app()->getStore()->getId());
        }

        if($collection->getSize() > 0){
            return @unserialize($collection->getFirstItem()->getValue());
        }
        return null;
    }

    public function _getAnalyticsSettings($appcode)
    {
        $collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
        $collection->addFieldToFilter('app_code', $appcode)
            ->addFieldToFilter('setting_code', 'googleanalytics');
        if($collection->getSize() > 0){
            return @unserialize($collection->getFirstItem()->getValue());
        }
        return null;
    }

    protected function _getWidgets($appcode, $categoryId = null)
    {
        $store = Mage::app()->getStore()->getId();
        if(empty($categoryId)){
            $collection = Mage::getModel('mobiadmin2/widget')->getCollection();
            $collection->addFieldToFilter('widget_app_code', $appcode)
                ->addFieldToFilter('widget_store_id', $store);
        }
        else{
            $collection = Mage::getModel('mobiadmin2/categorywidget')->getCollection();
            $collection->addFieldToFilter('widget_category_id', $categoryId);
        }
        $collection->addFieldToFilter('widget_status', '1');
        $collection->setOrder('widget_position', 'ASC');
        $data = array();
        if($collection->getSize() > 0){
            foreach($collection as $_collection){
                $_data = array(
                    'widget_id'    => $_collection->getWidgetId(),
                    'widget_label' => $_collection->getWidgetLabel(),
                    'widget_code'  => $_collection->getWidgetCode(),
                    'widget_data'  => @unserialize($_collection->getWidgetData()),
                    );

                switch($_data['widget_code']){
                    case 'widget_category':
                        //echo '<pre>';print_r($_data['widget_data']['categories']);echo '</pre>';exit;
                        $output_ids = array();
                        $ids = json_decode($_data['widget_data']['categories']['id'], true);
                        //print_r($ids);exit;
                        if(is_array($ids) && !empty($ids)){
                            
                            $temp_ids = array();
                            $_category_array = array();
                            $_position_array = array();
                            foreach ($ids as $_category => $_position){
                                $temp_ids[] = array(
                                    'category' => $_category,
                                    'position' => $_position
                                    );
                                $_category_array[$_category] = $_category;
                                $_position_array[$_category] = $_position;
                            }
                            array_multisort($_position_array, SORT_ASC, $_category_array, SORT_ASC, $temp_ids);

                            $ids = array();
                            foreach ($temp_ids as $key => $value) {
                                $ids[$value['category']] = $value['position'];
                            }
                        }

                        $categoryArray = array();
                        $categories = $this->getCacheData('category', $appcode);

                        foreach($categories as $_category){
                            $categoryArray[$_category['category_id']] = $_category;
                        }
                        if(is_array($ids) && !empty($ids)){
                            foreach($ids as $_key => $_value){
                                if(isset($categoryArray[$_key]))
                                    $output_ids[] = $categoryArray[$_key];
                            }
                        }
                        //print_r($output_ids);exit;
                        //$output_ids = array_filter(array_unique($output_ids));

                        if(empty($output_ids))
                            $_data = null;
                        else
                            $_data['widget_data']['categories']['id'] = $output_ids;
                        break;
                    case 'widget_product_slider':
                        $productResultArray = array();
                        if(!in_array($_data['widget_data']['productslider_type'], array('newarrivals', 'bestseller', 'productviewed'))){
                            $ids = json_decode($_data['widget_data']['products']['id'], true);
                            $output_ids = array();
                            foreach($ids as $_key => $_value){
                                $output_ids[] = $_key;
                            }

                            $productsArray = array();
                            $collection = Mage::getModel('catalog/product')->getCollection()
                                ->addAttributeToSelect('*')
                                ->addAttributeToFilter('status', '1')
                                ->addAttributeToFilter('visibility', '4')
                                ->addAttributeToFilter('entity_id', array('in' => $output_ids))
                                ->setStoreId($store)
                                ->addMinimalPrice()
                                ->addFinalPrice();

                            if($collection->getSize() > 0){
                                foreach($collection as $_collection){
                                    $stock = true;
                                    if (version_compare(Mage::getVersion(), '1.4.0.1', '=') === true) {
                                        if (!$product->isSaleable()) $stock = false;
                                    }
                                    $_product = array(
                                        'product_id'              => $_collection->getId(),
                                        'entity_id'               => $_collection->getId(),
                                        'name'                    => $_collection->getName(),
                                        'type_id'                 => $_collection->getTypeId(),
                                        'price'                   => Mage::helper('mobiservices2/mobicommerce')->getProductPriceByCurrency($_collection->getPrice()),
                                        'special_price'           => Mage::helper('mobiservices2/mobicommerce')->getProductPriceByCurrency($_collection->getFinalPrice()),
                                        'stock_status'            => $stock,
                                        'product_reviews'         => Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/catalog_catalog'))->_getProductReviews($_collection->getId(), $store),
                                        'product_small_image_url' => NULL,
                                        'product_image_url'       => NULL,
                                        );
                                    try{
                                        $_product['product_small_image_url'] = Mage::helper('catalog/image')->init($_collection, 'small_image')->__toString();
                                        $_product['product_image_url'] = $_product['product_small_image_url'];
                                    }
                                    catch(Exception $e){}

                                    $prices = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/catalog_catalog'))->_productPrices($_collection);
                                    if ($prices) {
                                        $_product = array_merge($_product, $prices);
                                    }

                                    $productsArray[$_collection->getId()] = $_product;
                                }
                            }
                            foreach($output_ids as $_id){
                                if(isset($productsArray[$_id]))
                                    $productResultArray[] = $productsArray[$_id];
                            }
                            if(empty($productResultArray))
                                $_data = null;
                            else{
                                foreach ($productResultArray as $prkey => $prvalue) {
                                    $_prindex[$prkey] = $prvalue['sort_index'];
                                    $_prid[$prkey] = $prvalue['product_id'];
                                }
                                array_multisort($_prindex, SORT_ASC, $_prid, SORT_ASC, $productResultArray);
                                $_data['widget_data']['products']['id'] = $productResultArray;
                            }
                        }
                        else{
                            $_data['widget_data']['products']['id'] = $productResultArray;   
                        }
                        break;
                    case 'widget_image':
                        $mapcode = $_data['widget_data']['mapcode'];
                        $mapcode = $this->_getImagemapContent($mapcode, false);
                        if(empty($mapcode)){
                            $mapcode = '<img src="'.$_data['widget_data']['widget_image'].'" alt="">';
                        }
                        $_data['widget_data']['mapcode'] = $mapcode;
                        $filename = str_replace(Mage::getBaseUrl('media'), Mage::getBaseDir('media').'/', $_data['widget_data']['widget_image']);
                        list($width, $height, $type, $attr) = getimagesize($filename);
                        $ratio = 0;
                        if($height != 0){
                            $ratio = round(($width / $height), 2);
                        }
                        $_data['widget_data']['ratio'] = $ratio;
                        break;
                    case 'widget_image_slider':
                        $banners = array();
                        if(!empty($_data['widget_data']['banners'])){
                            foreach($_data['widget_data']['banners'] as $_key => $_value){
                                $filename = str_replace(Mage::getBaseUrl('media'), Mage::getBaseDir('media').'/', $_value['banner_url']);
                                if(isset($_value['banner_status']) && $_value['banner_status'] == '1' && file_exists($filename)){
                                    list($width, $height, $type, $attr) = getimagesize($filename);
                                    $_banner = $_value;

                                    $ratio = 0;
                                    if($height != 0){
                                        $ratio = round(($width / $height), 2);
                                    }
                                    $_banner['ratio'] = $ratio;
                                    $banners[] = $_banner;
                                }
                            }
                        }
                        if(empty($banners))
                            $_data = null;
                        else
                            $_data['widget_data']['banners'] = $banners;
                        break;
                }
                if(!empty($_data))
                    $data[] = $_data;
            }
        }
        return $data;
    }

    protected function _getSocialLogin($store = null)
    {
        $_social_login = array(
            'is_active' => Mage::getStoreConfig('mobisociallogin2/general/is_active', $store),
            'types' => array(
                
                'facebook' => array(
                    'is_active'  => Mage::getStoreConfig('mobisociallogin2/fblogin/is_active', $store),
                    'title'      => Mage::getStoreConfig('mobisociallogin2/fblogin/title', $store),
                    'url'        => Mage::getModel('mobisociallogin2/fblogin')->newFacebook()->getLoginUrl(array('scope' => 'email,public_profile', 'redirect_uri' => Mage::helper('mobisociallogin2')->getAuthUrl())),
                    'sort_order' => (int) Mage::getStoreConfig('mobisociallogin2/fblogin/sort_order', $store),
                    ),
                'twitter' => array(
                    'is_active'   => Mage::getStoreConfig('mobisociallogin2/twlogin/is_active', $store),
                    'title'       => Mage::getStoreConfig('mobisociallogin2/twlogin/title', $store),
                    'url'         => Mage::getBlockSingleton('mobisociallogin2/twlogin')->getLoginUrl(),
                    'redirecturl' => Mage::getStoreConfig('mobisociallogin2/twlogin/redirecturl', $store),
                    'sort_order'  => (int) Mage::getStoreConfig('mobisociallogin2/twlogin/sort_order', $store),
                    ),
                'google' => array(
                    'is_active'   => Mage::getStoreConfig('mobisociallogin2/gologin/is_active', $store),
                    'title'       => Mage::getStoreConfig('mobisociallogin2/gologin/title', $store),
                    'url'         => Mage::getBlockSingleton('mobisociallogin2/gologin')->getLoginUrl(),
                    'redirecturl' => Mage::getStoreConfig('mobisociallogin2/gologin/redirecturl', $store),
                    'sort_order'  => (int) Mage::getStoreConfig('mobisociallogin2/gologin/sort_order', $store),
                    ),
                ),
            );
    
        $social_login = array('is_active' => $_social_login['is_active'], 'types' => array());
        foreach($_social_login['types'] as $key => $_login){
            if($_login['is_active']){
                $social_login['types'][$key] = $_login;
            }
        }

        foreach ($social_login['types'] as $key => $row){
            $sort_order[$key] = $row['sort_order'];
            $is_active[$key]  = $row['is_active'];
        }
        array_multisort($sort_order, SORT_ASC, $is_active, SORT_ASC, $social_login['types']);

        return $social_login;
    }

    protected function _getImagemapContent($map, $decodeLink = true)
    {
        $map = htmlspecialchars_decode($map);
        $doc = new DOMDocument();
        $doc->loadHtml($map);
        $areas = $doc->getElementsByTagName('area');
        foreach($areas as $_area){
            $href = $_area->getAttribute("href");
            if($decodeLink){
                $link = $this->_decodeDeeplink($href);
                $map = str_replace('href="'.$href.'"', 'href="'.$link.'"', $map);
            }
            else{
                $map = str_replace('href="'.$href.'"', 'href ="javascript:app.f.imagemap(\''.$href.'\');"', $map);
            }
        }
        return $map;
    }

    protected function _decodeDeeplink($link = null)
    {
        if(!empty($link)){
            $explode = explode("||", $link);
            if(count($explode) == 2){
                $urltype = $explode['0'];
                $urltval = $explode['1'];
                if($urltype == 'product'){
                    $product = Mage::getModel('catalog/product')->load($urltval);
                    $link = $product->getProductUrl();
                }elseif($urltype == 'category'){
                    $link = Mage::getModel("catalog/category")->load($urltval)->getUrl();
                }elseif($urltype == 'cms'){
                    $link = Mage::getBaseUrl().$urltval.'.html';
                }elseif($urltype == 'phone'){
                    $link = "tel:'.$urltval.'";
                }elseif($urltype == 'email'){
                    $link = "mailto:'.$urltval.'";
                }elseif($urltype == 'external'){
                    $link = $urltval;
                }
            }
        }
        return $link;
    }

    protected function _getStores()
    {
        $stores = array();
        $_websites = Mage::app()->getWebsites();
        foreach ($_websites as $website){
            foreach ($website->getGroups() as $group){
                $groupStores = $group->getStores();
                foreach ($groupStores as $_store){
                    $stores[] = $_store->getData();
                }
            }
        }

        return $stores;
    }
}