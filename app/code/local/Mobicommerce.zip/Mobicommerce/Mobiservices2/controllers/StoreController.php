<?php
class Mobicommerce_Mobiservices2_StoreController extends Mobicommerce_Mobiservices2_Controller_Action {

    /**
     * Get all stores
     */
    public function storesAction()
    { 
        $data = $this->getData();   
        $info = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/store'))->getAllStores($data);
        $this->printResult($info);    
    }

    /**
     * Get all store locators
     */
    public function listAction()
    {
        $data = $this->getData();  
        $info = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/store'))->getStoreList();
        $this->printResult($info);
    }

    /**
     * Get store locator detail
     */
    public function detailAction()
    {
    	$data = $this->getData();  
        $info = Mage::getModel(Mage::getBlockSingleton('mobiservices2/connector')->_getConnectorModel('mobiservices2/store'))->getStoreDetail($data);
        $this->printResult($info);	
    }
}