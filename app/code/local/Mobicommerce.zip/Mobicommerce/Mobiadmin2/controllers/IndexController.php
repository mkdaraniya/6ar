<?php
class Mobicommerce_Mobiadmin2_IndexController extends Mage_Adminhtml_Controller_Action {
    
    public function indexAction()
    {
    	Mage::helper('mobiadmin2')->getMobicommercePrerequisites();
    	Mage::dispatchEvent('Mobicommerce_Mobiadmin2_createapp_predispatch', array());
	    $this->loadLayout();
		$this->_setActiveMenu('mobiadmin2');
		$this->getLayout()->getBlock('head')->setTitle('Manage Mobile Apps');
	    $this->renderLayout();
	}
    
	public function _setLanguageCode($locale)
	{
       	Mage::helper('mobiadmin2')->setLanguageCodeData($locale);
	}

	public function newAction()
	{
		Mage::helper('mobiadmin2')->getMobicommercePrerequisites();
		Mage::dispatchEvent('Mobicommerce_Mobiadmin2_createapp_predispatch', array());
	    $this->loadLayout();
		$this->_setActiveMenu('mobiadmin2');	
		$this->getLayout()->getBlock('head')->setTitle('Create New Mobile App');
	    $this->renderLayout();
	}

	public function createAppAction()
	{
		$max_execution_time = ini_get('max_execution_time');
		if($max_execution_time != -1 && $max_execution_time < 300){
			ini_set('max_execution_time', 300);
		}
		$max_input_time = ini_get('max_input_time');
		if($max_input_time != -1 && $max_input_time < 300){
			ini_set('max_input_time', 300);
		}

		$refererUrl = $this->_getRefererUrl();
		
		$postData = Mage::app()->getRequest()->getPost();
		if(!isset($postData)){
			Mage::app()->getFrontController()->getResponse()->setRedirect($refererUrl);
			return;
		}
		$groupid = $postData['store'];
		$storeid = Mage::app()->getGroup($groupid)->getDefaultStore()->getStoreId();
		$configurations = array(
			'connectorVersionCode'   => '4602ed8ba66c1df84a638300e7d1ef2a697435f2',
			'max_execution_time'     => ini_get('max_execution_time'),
			'max_input_time'         => ini_get('max_input_time'),
			'ipaddress'              => isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'',
			'add_store_code_to_urls' => Mage::getStoreConfig('web/url/use_store'),
			'default_store_code'     => Mage::app()->getGroup($groupid)->getDefaultStore()->getCode(),
			'mobicommerce_version'   => Mage::helper('mobiadmin2')->getMobiBaseVersion(),
			);

		$validation = true;
		if(!empty($_FILES)){
			$images = array(
				"appsplash" => "Splash",
				"applogo"   => "Logo",
				"appicon"   => "Icon",
				);

			foreach($images as $_image_name => $_image_label){
				if($_FILES[$_image_name]['name'] != '' && strtolower(PATHINFO($_FILES[$_image_name]['name'], PATHINFO_EXTENSION)) != 'png'){
					Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__($_image_label.' must be png'));
					Mage::getSingleton('core/session')->setData( 'createapp', Mage::app()->getRequest()->getPost());
					$validation = false;
				}
			}

			if(!$validation){
				Mage::app()->getFrontController()->getResponse()->setRedirect($refererUrl);
				return;
			}
		}

		$this->__sendEmailBeforeCreateApp($postData);
		
		$curlData = $postData;
		$media_path = Mage::getBaseDir('media') .DS. 'mobi_commerce';
		$mediaUrl = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'mobi_commerce/';
		$mediaMobiAssetUrl = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'mobi_assets/defaults/';
		
		$images = array(
			"appsplash" => array(
				"w" => 1536,
				"h" => 2048,
				"r" => null
				),
			"applogo" => array(
				"w" => null,
				"h" => null,
				"r" => '1x8'
				),
			"appicon" => array(
				"w" => 1024,
				"h" => 1024,
				"r" => null
				)
			);
		foreach($images as $_image_name => $_image_size){
			if(isset($_FILES[$_image_name]['name']) && !empty($_FILES[$_image_name]['name'])){			
				try{
					$size = getimagesize($_FILES[$_image_name]['tmp_name']);
					if($_image_size['w'] != null && $_image_size['h'] != null && ($size[0] != $_image_size['w'] || $size[1] != $_image_size['h'])){
						Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__(ucfirst($_image_name).' Icon dimension must be '.$_image_size['w'].'X'.$_image_size['h']));
						Mage::getSingleton('core/session')->setData( 'createapp', Mage::app()->getRequest()->getPost());
					    Mage::app()->getFrontController()->getResponse()->setRedirect($refererUrl);			
					    return;
					}

					// ratio for logo should be 1hx8w. Cannot be more then that
					if(!empty($_image_size['r'])){
						$r = explode('x',$_image_size['r']);
						$h = (int) $r[0];
						$w = (int) $r[1];
						$ratio = $h / $w;
						$iratio = $size[1] / $size[0];
						if($iratio < $ratio){
							Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__(ucfirst($_image_name).' Icon dimension must have ratio of '.$h.'X'.$w));
							Mage::getSingleton('core/session')->setData( 'createapp', Mage::app()->getRequest()->getPost());
						    Mage::app()->getFrontController()->getResponse()->setRedirect($refererUrl);			
						    return;
						}
					}

					$uploader = new Varien_File_Uploader($_image_name);
					$uploader->setAllowRenameFiles(false);
					$uploader->setAllowCreateFolders(true);
					$filename = uniqid().'.'.PATHINFO($_FILES[$_image_name]['name'], PATHINFO_EXTENSION);
					$uploader->save($media_path, $filename);
					$curlData[$_image_name] = $mediaUrl.$filename;
				}catch(Exception $e){
					Mage::log($e);
					$this->_redirectError(502);
				}
			}
		}
		
		if(!isset($curlData['appsplash'])){
			$curlData['appsplash'] = $mediaMobiAssetUrl.'splash.png'; 
		}
		if(!isset($curlData['applogo'])){
			$curlData['applogo'] = $mediaMobiAssetUrl.'logo.png'; 
		}
		if(!isset($curlData['appicon'])){
			$curlData['appicon'] = $mediaMobiAssetUrl.'icon.png'; 
		}

		$this->__resetConnection();

		$curlData['approoturl'] = Mage::app()->getStore($storeid)->getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
		$curlData['media_url'] = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA);
		/* code for licence key */
		$LicenceModel = Mage::getModel('mobiadmin2/licence')->getCollection();
		$licencekey = "";
		if($LicenceModel->getLastItem()){
			$licencekey = $LicenceModel->getLastItem()->getMlLicenceKey();
		}
		$curlData['applicencekey'] = $licencekey;
		/* code for licence key - upto here */

		$curlData['configurations'] = $configurations;
        $fields_string = http_build_query($curlData);
		$ch = curl_init();
		//echo '<pre>';print_r($curlData);exit;
		$url = Mage::helper('mobiadmin2')->curlBuildUrl().'build/add'; 
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_NOBODY, TRUE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, count($curlData));
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($curlData));
		$result = curl_exec($ch);
		curl_close($ch);
		$result = json_decode($result, true);
		$this->__resetConnection();
		
		if(isset($result)){
		    if($result['status'] == 'success'){				
				$appid = null;
				if($result['data']['appcode']){
					$data = array(
						"groupId"               => $groupid,
						"version_type"			=> $curlData['version_type'],
						"app_name"              => $curlData['appname'],
						"app_code"              => $result['data']['appcode'],
						"app_preview_code"      => $result['data']['appkey'],
						"app_logo"              => $curlData['applogo'],
						"app_theme_folder_name" => $curlData['apptheme'],
						"android_status"        => $result['data']['android_status'],
						"android_url"           => $result['data']['android_url'],
						"ios_status"            => $result['data']['ios_status'],
						"ios_url"               => $result['data']['ios_url'],
						"udid"					=> $curlData['udid'],
						"webapp_url"            => $result['data']['webapp_url'],
						"app_license_key"		=> $licencekey,
						);
				    $appobject = Mage::getModel('mobiadmin2/applications')->saveApplicationData($data);
				    $appid = $appobject['appid'];
				}else{
				    Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__($result['message']));
					Mage::getSingleton('core/session')->setData( 'createapp', Mage::app()->getRequest()->getPost());
				}
				Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__($result['message']));
				$this->_redirect('mobicommerce2/index/edit', 
					array(
					'id'       => $appid,
					'_current' => true
                ));
		    }else {
				Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__($result['message']));
				Mage::getSingleton('core/session')->setData( 'createapp', Mage::app()->getRequest()->getPost());
			    Mage::app()->getFrontController()->getResponse()->setRedirect($refererUrl);
				return;
			}
		}else{
		   Mage::app()->getFrontController()->getResponse()->setRedirect($refererUrl);
	       return;
		}
	}

	public function editAction()
    {
    	Mage::helper('mobiadmin2')->getMobicommercePrerequisites();
		$id = $this->getRequest()->getParam('id', null);
		$model = Mage::getModel('mobiadmin2/applications');

		if($id){
			$model->load((int) $id);
            if ($model->getId()){
                $data = Mage::getSingleton('adminhtml/session')->getFormData(true);
                if($data){
                    $model->setData($data)->setId($id);
                }
            }
			else{
                Mage::getSingleton('adminhtml/session')->addError(Mage::helper('mobiadmin2')->__('Application does not exist'));
                $this->_redirect('*/*/');
            }
		}

		$storeid = $this->getRequest()->getParam('store', null);
		$groupid = $model->getAppStoregroupid();
		$default_storeid = Mage::app()->getGroup($groupid)->getDefaultStoreId();
		//$stores = Mage::app()->getGroup($groupid)->getStores();
		if(Mage::helper('mobiadmin2')->isMultiStoreView()){
			$stores = Mage::app()->getStores();
		}
		else{
			$stores = Mage::app()->getGroup($groupid)->getStores();
		}

		if(empty($storeid)){
			$url = Mage::helper('adminhtml')->getUrl('mobicommerce2/index/edit', array('id' => $id, 'store' => $default_storeid));
			Mage::app()->getFrontController()->getResponse()->setRedirect($url);
			return;
		}

		if(!$this->storeExistsInGroup($storeid, $stores)){
			Mage::getSingleton('adminhtml/session')->addError(Mage::helper('mobiadmin2')->__('Store does not exist'));
                $this->_redirect('*/*/');
		}

		if($this->getRequest()->getPost()){
			$this->update();
		}
		else{
			Mage::register('application_data', $model);
			$locale = Mage::helper('mobiadmin2')->getAppLocaleCode();
			if($locale){
				$this->_setLanguageCode($locale);
			}
			$this->loadLayout();
			$this->_setActiveMenu('mobiadmin2');	
			$this->getLayout()->getBlock('head')->setTitle($this->__('Edit App '.$model->getAppName()));
			$this->getLayout()->getBlock('head')->setCanLoadExtJs(true);
			$this->renderLayout();
		}
	}

	protected function storeExistsInGroup($storeid, $stores = null)
	{
		if(empty($stores))
			return false;

		$storeids = array();
		foreach($stores as $_store){
			$storeids[] = $_store->getStoreId();
		}

		if(in_array($storeid, $storeids))
			return true;
		else
			return false;
	}

	public function update()
	{
		if($this->getRequest()->getPost()){
			$storeid = $this->getRequest()->getParam('store', null);
            $appid = Mage::app()->getRequest()->getPost('appid');
            $postData = $this->getRequest()->getPost();
			$appCode = $postData['appcode'];
			$appKey = $postData['appkey'];
            $errors = false;

            /**  Validation for Image Widget **/
            $validation = true;
			$refererUrl = $this->_getRefererUrl();
			if(!empty($_FILES)) {
				if(isset($_FILES['widget_image']['name']) && !empty($_FILES['widget_image']['name'])) {
					$allowed =  array('gif','png' ,'jpg');
					$ext = strtolower(PATHINFO($_FILES['widget_image']['name'], PATHINFO_EXTENSION));
					if(!in_array($ext, $allowed)) {
						Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__('Widget Image File type must be image( png ,jpg ,gif )'));
						$validation = false;
					}
				}
				if(!$validation){
					Mage::app()->getFrontController()->getResponse()->setRedirect($refererUrl);
					return;
				}
			}
			/**  Validation for Image Widget **/

			//save widget data
			$this->saveWidget($postData);
			$this->saveGoogleAnalyticsSettings($postData);
			$this->saveAdvanceSettings($postData);

			/*
			* Saving personalize Data in Media Application Folder
			*/
			$appUrlXmlFile = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appCode.DS.'personalizer'.DS.'personalizer.xml';
			
			$doc = new DOMDocument('1.0');
			$doc->formatOutput = true;
			$root = $doc->createElement('mobicommerce_personalizer');
			$root = $doc->appendChild($root);
            foreach($postData['personalizer'] as $keyOption => $option_value){
				$optioncodenode = $doc->createElement($keyOption);
				$newdoc = $root->appendChild($optioncodenode);
			    foreach($option_value as $optioncode => $value){				
				   	$em = $doc->createElement($optioncode);       
				   	$text = $doc->createTextNode($value);
				   	$em->appendChild($text);
				   	$newdoc->appendChild($em);
				}
			}
			$doc->save($appUrlXmlFile);
            
			/*
			* Create Css File
			*/
			$theme_folder_name = $postData['themename'];
            if(file_exists($appUrlXmlFile)){
				$appCssFile = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appCode.DS.'personalizer'.DS.'personalizer.css';
				$svgParentFolder =  Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme_folder_name.DS.'personalizer'.DS.'svg';
				$svgFolder =  Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appCode.DS.'personalizer'.DS.'svg';
				$cssOptionPart = array();
                $personalliseXmlData = simplexml_load_file($appUrlXmlFile);
				foreach($personalliseXmlData as $personalliseXmlOption){
				    $OptionCssText = $personalliseXmlOption->css;
					$OptionSvgFilenames = $personalliseXmlOption->svg_filenames;
					$OptionCssText = implode("\r\n", explode('|', $OptionCssText));
				    $OptionCerrentColor = $personalliseXmlOption->current_value;					
					$cssOptionPart[] = str_replace("--COLOR--",$OptionCerrentColor, $OptionCssText);

					if(!empty($OptionSvgFilenames)){
						$OptionSvgFilenames = explode('|', $OptionSvgFilenames);
						if(!empty($OptionSvgFilenames)){
							foreach($OptionSvgFilenames as $svg_filename){
								if(file_exists($svgParentFolder . DS . $svg_filename)){
									$svg_image = file_get_contents($svgParentFolder . DS. $svg_filename);
									preg_match_all('/<style>(.*?)<\/style>/s', $svg_image, $style_tag);
									if(isset($style_tag[1][0])){
										$old_style_tag = $style_tag[1][0];
										$property = explode('{', $style_tag[1][0]);
										$property = $property[0];
										preg_match_all('/{(.*?)}/s', $style_tag[1][0], $style_tag);
										$param = explode(':', $style_tag[1][0]);
										$param = $param[0];
										$is_rgb = strpos($OptionCerrentColor, ',');
										if(empty($is_rgb))
											$new_style_tag = $property.'{'.$param.':'.$OptionCerrentColor.'!important;}';
										else
											$new_style_tag = $property.'{'.$param.':rgb('.$OptionCerrentColor.')!important;}';
										
										$svg_image = str_replace($old_style_tag, $new_style_tag, $svg_image);
										if(file_exists($svgFolder . DS . $svg_filename)){
											@unlink($svgFolder . DS . $svg_filename);
										}
										file_put_contents($svgFolder . DS . $svg_filename, $svg_image);
									}
								}
							}
						}
					}
				}
				file_put_contents($appCssFile,implode($cssOptionPart,"\r\n"));
			}

            $appinfoimageurl = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/'. 'mobi_commerce'.'/'.$appCode.'/'.'appinfo'.'/';

            /*
			* Saving Push Notification Data With IOSPEM File Uploader
			*/
			if(isset($_FILES['upload_iospem_file']['name']) && !empty($_FILES['upload_iospem_file']['name'])){
				try{
					$uploader = new Varien_File_Uploader('upload_iospem_file');
                    $uploader->setAllowRenameFiles(false);
                    $uploader->setAllowCreateFolders(true);
					$media_path = Mage::getBaseDir('media') .DS. 'mobi_commerce'.DS.$appCode.DS.'appinfo'.DS ;
					$iospemFilename = uniqid().'.'. PATHINFO($_FILES['upload_iospem_file']['name'], PATHINFO_EXTENSION);
					$uploader->save($media_path, $iospemFilename);
				}catch (Exception $e){
				    Mage::log($e);
                    $this->_redirectError(502);
				}
				$data['upload_iospem_file'] = $iospemFilename;			
			}			
			
			if(!isset($postData['pushnotification']['active_push_notification'])){
			    $postData['pushnotification']['active_push_notification'] = '0';
			}

            if(!isset($postData['pushnotification']['sandboxmode'])){
				$postData['pushnotification']['sandboxmode'] = '0';
			}

			$pushNotificationData = $postData['pushnotification'];
			if(isset($data['upload_iospem_file']) && $data['upload_iospem_file']){
			    $pushNotificationData['upload_iospem_file_url'] = $appinfoimageurl.$data['upload_iospem_file'];
			    $pushNotificationData['upload_iospem_file'] = $data['upload_iospem_file'];
			}else{
				$pushNotificationData['upload_iospem_file_url'] = $appinfoimageurl.$postData['upload_iospem_file_name'];
				$pushNotificationData['upload_iospem_file'] = $postData['upload_iospem_file_name'];
			}
			if(isset($postData['upload_iospem_file']['delete']) && $postData['upload_iospem_file']['delete'] == 1){
			    $pushNotificationData['upload_iospem_file_url'] = '';
			    $pushNotificationData['upload_iospem_file'] = '';
			}
			$pushNotificationSerData = serialize($pushNotificationData);

            $applicationSettingCollection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
			$applicationSettingCollection = $applicationSettingCollection
				->addFieldToFilter('app_code', $appCode)
			    ->addFieldToFilter('setting_code', 'push_notification');
			foreach($applicationSettingCollection as $pushnotification){
			   	$pushnotification->setData('value', $pushNotificationSerData)->save();
			}
            
			/*
			* Saving Application Information Data With App Share Image
			*/
			if(isset($_FILES['app_share_image']['name']) && !empty($_FILES['app_share_image']['name'])){
				try{
					$uploader = new Varien_File_Uploader('app_share_image');
                    $uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
                    $uploader->setAllowRenameFiles(false);
                    $uploader->setAllowCreateFolders(true);
					$media_path = Mage::getBaseDir('media') .DS. 'mobi_commerce'.DS.$appCode.DS.'appinfo'.DS;
					$shareImagename = uniqid().'.'.PATHINFO($_FILES['app_share_image']['name'], PATHINFO_EXTENSION);
					$uploader->save($media_path, $shareImagename);
				}catch (Exception $e){
				    Mage::log($e);
                    $this->_redirectError(502);
				}
				$data['app_share_image'] = $shareImagename;			
			}			
			$appInfoData = $postData['appinfo'];
			if(isset($data['app_share_image']) && $data['app_share_image']){
			    $appInfoData['app_share_image'] = $appinfoimageurl.$data['app_share_image'];
			}else if(isset($postData['app_share_image']['value'])){
				$appInfoData['app_share_image'] = $postData['app_share_image']['value'];
			}
			else{
				$appInfoData['app_share_image'] = '';	
			}

			if(isset($postData['app_share_image']['delete']) && $postData['app_share_image']['delete'] == 1){
			    $appInfoData['app_share_image'] = '';
			}

			$appInfoJsonData = serialize($appInfoData);
            $applicationSettingCollection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
			$applicationSettingCollection = $applicationSettingCollection
				->addFieldToFilter('app_code', $appCode)
			    ->addFieldToFilter('setting_code','appinfo');    
            foreach($applicationSettingCollection as $appinfo){
			    $appinfo->setData('value', $appInfoJsonData)->save();
			}
			
			/*
			* Save Cms Content Data with Contact Information
			*/
            $cmscontentarray = array();
			$cmscontentarray['contact_information'] = $postData['contact_information'];
            $cmscontentarray['social_media'] = $postData['social_media'];
            $cmsSelected = array();
            if(isset($postData['cms_pages']['status']) && !empty($postData['cms_pages']['status'])){
            	foreach($postData['cms_pages']['status'] as $_cms_id => $_cms){
            		$cmsSelected[] = array(
						'id'    => $_cms_id,
						'index' => isset($postData['cms_pages']['index'][$_cms_id]) ? (int) $postData['cms_pages']['index'][$_cms_id] : false
            			);
            	}

            	foreach ($cmsSelected as $key => $row) {
				    $cmsids[$key] = $row['id'];
				    $cmsindexes[$key] = $row['index'];
				}
				array_multisort($cmsindexes, SORT_ASC, $cmsids, SORT_ASC, $cmsSelected);
            }
            
            $cmscontentarray['cms_pages'] = $cmsSelected;
			$cmscontentarray = serialize($cmscontentarray);
			$applicationSettingCollection = Mage::getModel('mobiadmin2/appsetting')->getCollection()
				->addFieldToFilter('app_code', $appCode)
				->addFieldToFilter('storeid', $storeid)
			    ->addFieldToFilter('setting_code', 'cms_settings');
				
			/* Added by tauseef */
			if($applicationSettingCollection->getSize() > 0){
				foreach($applicationSettingCollection as $cmssetting){
					$cmssetting->setData('value', $cmscontentarray)->save();
				}
			}else{
				$applicationSettingCollection = Mage::getModel('mobiadmin2/appsetting');
				$applicationSettingCollection->setData('app_code', $appCode);
				$applicationSettingCollection->setData('storeid', $storeid);
				$applicationSettingCollection->setData('setting_code', "cms_settings");
				$applicationSettingCollection->setData('value', $cmscontentarray);
				$applicationSettingCollection->save();
			}
			/* Added by tauseef - upto here */


			/* update test devices */
			$collection = Mage::getModel('mobiadmin2/appsetting')->getCollection()
				->addFieldToFilter('app_code', $appCode)
				->addFieldToFilter('setting_code', 'push_testdevices');

			$push_testemails = explode(',', $postData['push_testemails']);
			$push_testemails = array_filter(array_unique(array_map('trim', $push_testemails)));
			foreach($collection as $_collection){
				$_collection->setValue(serialize($push_testemails))->save();
			}
			/* update test devices - upto here */
			
			/*
			* Sending Android and IOS Push Notification
            */
            $pushheading = $postData['pushheading'];
            $pushmessage = $postData['pushnotifications'];
            if(!empty($pushheading) && !empty($pushmessage)){
				$androidDevices = array();
				$iosDevices = array();

				$whom = $postData['whom'];
				if($whom == 'test'){
					$devices = Mage::helper('mobiadmin2')->getTestDevices($appCode);
					$androidDevices = $devices['devices']['android'];
					$iosDevices = $devices['devices']['ios'];
				}
				else{
					$deviceCollection = Mage::getModel('mobiadmin2/devicetokens')->getCollection()
						->addFieldToFilter('md_appcode',$appCode)
						->addFieldToFilter('md_devicetype',array('in' => array('android','ios')));

					if(!empty($deviceCollection)){
						foreach($deviceCollection as $_device){
							if($_device['md_devicetype'] == 'android'){
								$androidDevices[] = $_device['md_devicetoken'];
							}
							else{
								$iosDevices[] = $_device['md_devicetoken'];
							}
						}
					}
				}
				// check if deeplink contains cms page or not.
				$pushdeeplink = $postData['pushdeeplink'];
				if(!empty($pushdeeplink)){
					$link = explode('||', $pushdeeplink);
					if(count($link) == 2){
						if($link[0] == 'cms'){
							/*
							$cms = Mage::getModel('cms/page')->load($link[1], 'identifier')->getData();
							$link[1] = isset($cms['page_id']) ? $cms['page_id'] : null;
							*/
						}
					}
					$pushdeeplink = implode('||', $link);
				}
				
				$pushparams = array(
					'heading'   => $pushheading,
					'message'   => $pushmessage,
					'deeplink'  => $pushdeeplink,
					'image_url' => null
					);

				if(isset($_FILES['pushfile']['name']) && !empty($_FILES['pushfile']['name'])){
					$path = Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appCode.DS.'pushnotification';
					$fname = uniqid().'.'.PATHINFO($_FILES['pushfile']['name'], PATHINFO_EXTENSION);
					$uploader = new Varien_File_Uploader('pushfile');
		            $uploader->setAllowedExtensions(array('jpg','gif','png','jpeg'));
		            $uploader->setAllowCreateFolders(true);
		            $uploader->setAllowRenameFiles(true);
		            $uploader->setFilesDispersion(false);
		            $result = $uploader->save($path, $fname);
		            $pushparams['image_url'] = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'mobi_commerce/'.$appCode.'/pushnotification/'.$result['file'];
				}

				$pushsizeArray = $pushparams;
				if(!empty($pushparams['image_url'])){
					//$pushsizeArray['image_url'] = file_get_contents($pushparams['image_url']);
				}
				$pushsize = serialize($pushsizeArray);
				if (function_exists('mb_strlen')) {
				    $pushsize = mb_strlen($pushsize, '8bit');
				} else {
				    $pushsize = strlen($pushsize);
				}
				
				if($pushsize > 4096){
					$errors[] = Mage::helper('adminhtml')->__('Push notification size is '.$pushsize.' bytes. It should not be greater then 4096 bytes');
				}
				else{
					if(!empty($androidDevices)){
						if(in_array($postData['push_device_type'], array('android', 'both'))){
							$this->androidpushnotification($pushparams, $pushNotificationData, $androidDevices);
						}
					}
	            	if(!empty($iosDevices)){
	            		if(in_array($postData['push_device_type'], array('ios', 'both'))){
							$this->iospushnotification($pushparams, $pushNotificationData, $iosDevices);
						}
	            	}
				}
            }

			if(isset($postData['udid']) && !empty($postData['udid'])){
                $udids = $postData['udid'];
				$datatosend = array('udid' => $udids);
				
				$ch = curl_init();
				$url = Mage::helper('mobiadmin2')->curlBuildUrl().'/build/submitudid/'.$appKey.'/'.$appCode;
				curl_setopt($ch, CURLOPT_HEADER, FALSE);
				curl_setopt($ch, CURLOPT_NOBODY, TRUE);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
				curl_setopt($ch,CURLOPT_URL, $url);
				curl_setopt($ch,CURLOPT_POST, count($datatosend));
				curl_setopt($ch,CURLOPT_POSTFIELDS, http_build_query($datatosend));
				$result = curl_exec($ch);		
				curl_close($ch);
				$result = json_decode($result, true);
				if(isset($result)) {
					if($result['status'] == 'success'){
						$applicationsCollection  = Mage::getModel('mobiadmin2/applications')->getCollection()
							->addFieldToFilter('app_code', $appCode);
			
						foreach($applicationsCollection as $application){
						   	$application
							   ->setData('udid', $udids)
							   ->setData('ios_url', $result['data']['ios_url'])
							   ->setData('ios_status', $result['data']['ios_status'])
							   ->save();
						}
					
					}else{
						Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__($result['message']));
						$this->_redirect('*/*/edit', array(
							'id'    => $appid,
							'_current'=>true
						));
					}
				}
			}

			Mage::helper('mobiservices2/cache')->flushAllCache();
			
            if(isset($errors) && !empty($errors)){
                Mage::getSingleton('adminhtml/session')->addError(Mage::helper('adminhtml')->__(implode(',', $errors)));
			}else{
				$message = $this->__('Application is successfully Save.');
                Mage::getSingleton('core/session')->addSuccess($message);
			}

			$this->_redirect('*/*/edit', array(
				'id'       => $appid,
				'_current' =>true
            ));
		}
		else{
			$this->_redirect('mobicommerce2', array(
                'id'    => $appid,
                '_current'=>true
            )); 
		}
	}
	
	function androidpushnotification($pushparams, $pushdata, $devices = array())
	{
		$android_key = $pushdata['android_key'];
		if(!empty($android_key) && !empty($devices) && !empty($pushparams['heading']) && !empty($pushparams['message'])){
			$msg = array(
				'message'  => $pushparams['message'],
				'title'    => $pushparams['heading'],
				'deeplink' => $pushparams['deeplink'],
				'imageurl' => $pushparams['image_url'],
				'vibrate'  => 1,
				'sound'    => 1,
				'notId'    => time()
			);
			//echo '<pre>';print_r($msg);exit;

			$headers = array(
				'Authorization: key=' . $android_key,
				'Content-Type: application/json'
				);

			/**
			 * done by tauseef
			 * as android is not taking more then 1000 devices in one call
			 * date: 21-01-2016
			 */
			$androidDevices = array_chunk($devices, 1000);
			foreach($androidDevices as $adevices){
				$fields = array(
					'registration_ids' => $adevices,
					'data'             => $msg
				);
				
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
				$result = curl_exec($ch);
				curl_close($ch);
			}
		}
	}

	function iospushnotification($pushparams, $pushdata, $devices = array())
	{
		$sandboxmode = false;
        $passphrase = $pushdata['pem_password'];
		$pemFile = $pushdata['upload_iospem_file_url'];
		$pemFile = str_replace(Mage::getBaseUrl('media'), Mage::getBaseDir('media').'/', $pemFile);
		//echo '<pre>';print_r($pemFile);exit;
		if(isset($pushdata['sandboxmode']) && $pushdata['sandboxmode'] == '1'){
			$sandboxmode = true;
		}
		
		if(!empty($pemFile) && !empty($pushparams['message'])){
			$ctx = stream_context_create();
			stream_context_set_option($ctx, 'ssl', 'local_cert', $pemFile);
			stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

			// Open a connection to the APNS server
			$push_url = "ssl://gateway.push.apple.com:2195";
			if($sandboxmode){
				$push_url = "ssl://gateway.sandbox.push.apple.com:2195";
			}
			
			if(!empty($devices)){
				foreach ($devices as $key => $value) {

					$fp = stream_socket_client(
						$push_url, $err,
						$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

					/*
					exec("telnet gateway.push.apple.com 2195", $a);
					print_r($a);exit;
					*/

					if(!$fp){
						//die("Failed to connect: $err $errstr");
						return "Failed to connect: $err $errstr" . PHP_EOL;
					}
					else{
						//die("connected");
					}

					//echo 'Connected to APNS' . PHP_EOL;
					$body['aps'] = array(
						'alert'    => $pushparams['message'],
						'sound'    => 'default',
						'deeplink' => $pushparams['deeplink']
						);
					$payload = json_encode($body);
			
					$msg = chr(0) . pack('n', 32) . pack('H*', $value) . pack('n', strlen($payload)) . $payload;
					$result = fwrite($fp, $msg, strlen($msg));
					if(!$result){
						//echo 'Message not delivered' . PHP_EOL;
					}
					else{
						//echo 'Message successfully delivered' . PHP_EOL;
					}
					fclose($fp);
				}
			}
			return true;
		}
		return false;
	}

	public function notificationAction()
	{
		Mage::helper('mobiadmin2')->getMobicommercePrerequisites();
	    $this->loadLayout();
		$this->_setActiveMenu('mobiadmin2');	
		$this->getLayout()->getBlock('head')->setTitle('Mobicommerce Notification');
	    $this->renderLayout();
	}

	public function massReadAction()
	{
		$ids = Mage::app()->getRequest()->getParam('ids');
		if(is_array($ids)){		   		
			foreach($ids as $id){
			   $model = Mage::getModel('mobiadmin2/notification');
               $model->setId($id)->setReadStatus('1')->save();
			}
			Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('The message has been marked as read.'));
			$this->_redirect('mobicommerce2/index/notification');
		}
		$this->_redirect('mobicommerce2/index/notification');
	}

	public function massDeleteAction()
	{
	    $ids = Mage::app()->getRequest()->getParam('ids');
		if(is_array($ids)){		   		
			foreach($ids as $id){
			   	$model = Mage::getModel('mobiadmin2/notification');
               	$model->setId($id)->delete();
			}
			Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Message was successfully deleted'));
			$this->_redirect('mobicommerce2/index/notification');
		}
		$this->_redirect('mobicommerce2/index/notification');
	}
    
	public function deletenotificationAction()
	{
		if($this->getRequest()->getParam('id') > 0){
            try{
                $model = Mage::getModel('mobiadmin2/notification');
                $model->setId($this->getRequest()->getParam('id'))
                    ->delete();
                      
                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Message was successfully deleted'));
                $this->_redirect('mobicommerce2/index/notification');
            }catch(Exception $e){
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/', array('id' => $this->getRequest()->getParam('id')));
            }
        }
        $this->_redirect('mobicommerce2/index/notification');
	}

	public function readnotificationAction()
	{
		if($this->getRequest()->getParam('id') > 0){
            try{
                $model = Mage::getModel('mobiadmin2/notification');
                $model->setId($this->getRequest()->getParam('id'))
                    ->setReadStatus('1')->save();
                      
                Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('The message has been marked as read.'));
                $this->_redirect('mobicommerce2/index/notification');
            }catch(Exception $e){
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/', array('id' => $this->getRequest()->getParam('id')));
            }
        }
        $this->_redirect('mobicommerce2/index/notification');	   
	}

	public function sendemailAction()
	{
	    $postData = Mage::app()->getRequest()->getPost();
		$isAjax = Mage::app()->getRequest()->getParam('isAjax');
		if($isAjax) {
			$user = Mage::getSingleton('admin/session');
			$fromEmail = $user->getUser()->getEmail();
			$from = $user->getUser()->getFirstname();
			$to = $postData['emailid'];
			if($postData['templatetype'] == 'android'){
				$body = "<b>Hello</b>, <br><br> ".$from." has sent you a MobiCommerce Android Demo App to review, by clicking the URL you can download and install the Mobile app in your Mobile Device.<br><br> MobiCommerce Android  App URL: ".$postData['appurl']." <br><br><i>'".$this->__('Note: If you have any mobicommerce demo app installed in your mobile device please uninstall that before installing a new mobicommerce demo app')."'</i> <br><br> Regards";
			}elseif($postData['templatetype'] == 'ios'){
				$body = "<b>Hello</b>, <br><br> ".$from." has sent you a MobiCommerce iOS Demo App to review, by clicking the URL you can download and install the Mobile app in your Mobile Device.<br><br> MobiCommerce iOS  App URL: ".$postData['appurl']." <br><br><i>'".$this->__('Note: If you have any mobicommerce demo app installed in your mobile device please uninstall that before installing a new mobicommerce demo app')."'</i> <br><br> Regards";
			}elseif($postData['templatetype'] == 'website'){
				$body = "<b>Hello</b>, <br><br> ".$from." has sent you a MobiCommerce provided Mobile Website to review, by clicking the URL you can review mobile website in your Mobile Devices.<br><br> MobiCommerce Mobile Website URL: ".$postData['appurl']."  <br><br> Regards";
			}
			$subject = "Mobicommerce App URL";
			$mail = new Zend_Mail();
			$mail->setBodyText('Mobicommerce App Url');
			$mail->setBodyHtml($body);
			$mail->setFrom($fromEmail, $from);
			$mail->addTo($to);
			$mail->setSubject($subject);
			try{
			    $mail->send();
				$response['status'] = "success";
				$response['success'] = 'Successfully sent Email.';
				$this->getResponse()->setBody(json_encode($response));	
			}catch(Exception $ex) {
				$response['status'] = "fail";
			    $response['error'] = 'Unable to send email.';
				$this->getResponse()->setBody(json_encode($response));
			}
		}		
	}

	protected function __sendEmailBeforeCreateApp($data)
	{
		if(!empty($data)){
			$groupId = $data['store'];
			$storeId = 0;
			foreach (Mage::app()->getWebsites() as $website){
			    foreach ($website->getGroups() as $group){
			    	if($group->getGroupId() == $groupId){
			    		$storeId = $group->getDefaultStoreId();
			    	}
			    }
			}
            $storeUrl = Mage::app()->getStore($storeId)->getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
			$body = "App Name:- ".$data['appname']." <br>  Store Url:-  ".$storeUrl." <br> Email Id :- ".$data['primaryemail']." <br> Phone Number:- ".$data['phone_country_code']."-".$data['phone']."";
            $to = Mage::helper('mobiadmin2')->mobicommerceEmailId();
			$user = Mage::getSingleton('admin/session');
			$from = $user->getUser()->getEmail();
			$mail = new Zend_Mail();
			$mail->setBodyText('Mobicommerce Create App Request');
			$mail->setBodyHtml($body);
			$mail->setFrom($from, $data['appname']);
			$mail->addTo($to, 'Mobicommerce');
			$mail->setSubject("Create App Request From ".$storeUrl);
			try {$mail->send();}
			catch (Exception $e){}
		}
	}

	protected function __resetConnection()
	{
		$db = Mage::getSingleton('core/resource')->getConnection('core_read');
		$db->closeConnection();
		$db->getConnection();
		$db = Mage::getSingleton('core/resource')->getConnection('core_write');
		$db->closeConnection();
		$db->getConnection();
	}

	public function labelsmessagesAction()
	{
		Mage::helper('mobiadmin2')->getMobicommercePrerequisites();
		$locale = Mage::app()->getRequest()->getParam('lang_code');
		$post = Mage::app()->getRequest()->getPost();
		if($post['form_key']){
			$languageData = $post['language_data'];

			$xml = Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_assets/multilanguage/'.$locale.'.xml';
			$xmldata = simplexml_load_file($xml);

			$childxml = Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_commerce/multilanguage/'.$locale.'.xml';
			$doc = new DOMDocument('1.0');
		    $doc->formatOutput = true;
		    $root = $doc->createElement('mobicommerce_multilanguage');
		    $root = $doc->appendChild($root);

		    foreach($xmldata as $_key => $_data){
	        	$optioncodenode = $doc->createElement($_key);
	            $newdoc = $root->appendChild($optioncodenode);

	            $em = $doc->createElement('mm_text');
	            $text = $doc->createTextNode(isset($languageData[$_key]) ? $languageData[$_key] : $_data->mm_text);
	            $em->appendChild($text);
	            $newdoc->appendChild($em);
	        }
	        $doc->save($childxml);

			$redirectUrl = Mage::helper('adminhtml')->getUrl('mobiadmin2/index/labelsmessages').'lang_code/'.$locale;
			Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('adminhtml')->__('Labels and Messages are save sucessfully.'));
			Mage::app()->getFrontController()->getResponse()->setRedirect($redirectUrl);
			return;
		} else {
            if($locale){
            	Mage::helper('mobiadmin2')->setLanguageCodeData($locale);
			    $this->loadLayout();
			    $this->_setActiveMenu('mobiadmin2');
				$this->getLayout()->getBlock('head')->setTitle('Labels and Messages');
		        $this->renderLayout();
			}
			else{
				$storearray = array();
                $_websites = Mage::app()->getWebsites();
				foreach ($_websites as $website){
					foreach ($website->getGroups() as $group){
						$stores = $group->getStores();
						foreach ($stores as $store){
							$storearray[] = Mage::getStoreConfig('general/locale/code', $store->getId());
						}
					}
				}
				$redirectUrl = Mage::helper('adminhtml')->getUrl('mobiadmin2/index/labelsmessages').'lang_code/'.$storearray['0'];
				Mage::app()->getFrontController()->getResponse()->setRedirect($redirectUrl);
			    return;
			}
		}
	}

	public function saveWidget($post)
	{
		$store_id = Mage::app()->getRequest()->getParam("store");

		$this->saveWidgetPosition($post);
		$widget_data = $post['widget'];
		$media_url = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA);
		//$media_url = Mage::getUrl('', array('_store' => $store_id)).'media/'; for multiwebsite added by dharmendra jain
		$media_dir = Mage::getBaseDir('media');
		$appgalleryimageurl = $media_url.'/'. 'mobi_commerce'.'/'.$post['appcode'].'/'.'home_banners'.'/';
		$media_path =  $media_dir.DS. 'mobi_commerce'.DS.$post['appcode'].DS.'home_banners'.DS ;
		$widget_media_path =  $media_dir.DS.'mobi_commerce'.DS.$post['appcode'].DS.'widget_image'.DS;
		$widgetimageurl = $media_url.'/'.'mobi_commerce'.'/'.$post['appcode'].'/'.'widget_image'.'/';
		if(!empty($post['widget_id'])) {
		    $widgetModel = Mage::getModel('mobiadmin2/widget')->load($post['widget_id']);
		    if(isset($_FILES['banners']['error']) && !empty($_FILES['banners']['error'])){
		    	foreach($_FILES['banners']['error'] as $i => $errorcount) {
					if($errorcount == '0'){
						$img_name = uniqid().'.'.PATHINFO($_FILES['banners']['name'][$i], PATHINFO_EXTENSION);
						$directory_gallery = $media_path.$img_name;
						move_uploaded_file($_FILES['banners']['tmp_name'][$i], $directory_gallery);
						$widget_data['widget_data']['banners'][$i]['banner_url'] = $appgalleryimageurl.$img_name;
					}				
				}
		    }
			$widget_data['widget_data']['widget_image'] = $post['widget_image_hidden'];
            if($widgetModel->getWidgetCode() == 'widget_category'){
				$categories = array();
				$savecat = array();
				if(count($widget_data['widget_data']['categories']['id'])){
					foreach($widget_data['widget_data']['categories']['id'] as $cat_id){
						$categories['id'] = $cat_id;
						if(!empty($widget_data['widget_data']['category_position_'.$cat_id])){
						    $categories['position'] = $widget_data['widget_data']['category_position_'.$cat_id];
						}
						if($widget_data['widget_data']['category_navigate_'.$cat_id] == 1){
						    $categories['navigate'] = $widget_data['widget_data']['category_navigate_'.$cat_id];
						}else{
							$categories['navigate'] = 0;
						}
						$savecat[] = $categories;
					}					
				}
				$widget_data['widget_data']['save_categories'] = $savecat;
			}
			//echo '<pre>';print_r($widget_data['widget_data']);exit;
			$widgetModel
				->setWidgetId($post['widget_id'])
				->setWidgetLabel($widget_data['name'])
				->setWidgetStatus($widget_data['enable'])
				->setWidgetData(serialize($widget_data['widget_data']))
				->save();
		} else {
			if(!empty($widget_data['selected_widget'])) {	
				if($widget_data['selected_widget'] == 'widget_image_slider'){
					if(isset($_FILES['banners']['error']) && !empty($_FILES['banners']['error'])){
						foreach($_FILES['banners']['error'] as $i => $errorcount) {
							if($errorcount == '0'){
								$img_name = uniqid().'.'.PATHINFO($_FILES['banners']['name'][$i], PATHINFO_EXTENSION);
								$directory_gallery = $media_path.$img_name;
								move_uploaded_file($_FILES['banners']['tmp_name'][$i],$directory_gallery);
								$widget_data['widget_data']['banners'][$i]['banner_url'] = $appgalleryimageurl.$img_name;
							}
						}
					}
				}
				$widget_data['widget_data']['widget_image'] = $post['widget_image_hidden'];
				if($widget_data['selected_widget'] == 'widget_category'){
					$categories = array();
					$savecat = array();
					if(count($widget_data['widget_data']['categories']['id'])){
						foreach($widget_data['widget_data']['categories']['id'] as $cat_id){
							$categories['id'] = $cat_id;
							if(!empty($widget_data['widget_data']['category_position_'.$cat_id])){
								$categories['position'] = $widget_data['widget_data']['category_position_'.$cat_id];
							}
							if($widget_data['widget_data']['category_navigate_'.$cat_id] == 1){
								$categories['navigate'] = $widget_data['widget_data']['category_navigate_'.$cat_id];
							}else{
								$categories['navigate'] = 0;
							}
							$savecat[] = $categories;
						}					
					}
					$widget_data['widget_data']['save_categories'] = $savecat;
				}
				if($widget_data['selected_widget'] == 'widget_product_slider'){
					$products = array();
					$saveproducts = array();
					if(count($widget_data['widget_data']['products']['id'])){
						foreach($widget_data['widget_data']['products']['id'] as $prod_id){
							$products['id'] = $prod_id;
							if(!empty($widget_data['widget_data']['product_position_'.$prod_id])){
								$products['position'] = $widget_data['widget_data']['product_position_'.$prod_id];
							}							
							$saveproducts[] = $products;
						}					
					}
					$widget_data['widget_data']['save_products'] = $saveproducts;				
				}
				$data_to_save = array(
					'widget_code'     => $widget_data['selected_widget'],
					'widget_app_code' => $post['appcode'],
					'widget_label'    => $widget_data['name'],
					'widget_status'   => $widget_data['enable'],
					'widget_store_id' => $this->getRequest()->getParam('store', null),
					'widget_data'     => serialize($widget_data['widget_data']),
				);
				Mage::getModel('mobiadmin2/widget')->setData($data_to_save)->save();	
			}
		}
	}

	public function saveWidgetPosition($post)
	{
	    if(isset($post['widget_position']) && count($post['widget_position'])) {
		    foreach($post['widget_position'] as $widget_id => $position) {		 	    
				$widgetModel = Mage::getModel('mobiadmin2/widget')->load($widget_id);
				$widgetModel->setWidgetPosition($position)->save();
			}
	    }	 
	}

	/**
	 * Created by Yash
	 * Date: 17-07-2015
	 * Whatever product attributes user select, database will save rest of the attributes as disabled attributes
	 * so if user add more attributes, it will be by default enabled
	 */
	public function saveAdvanceSettings($data)
	{
		$storeid = $this->getRequest()->getParam('store', null);

		if(isset($data['advancesettings']) && !empty($data['advancesettings'])){
			$advancesettings = $data['advancesettings'];
			$disabled_attributes = array();
			$attributes = Mage::helper('mobiadmin2')->getProductAttributes();
			if($attributes){
				foreach($attributes as $_attr){
					$disabled_attributes[$_attr['code']] = 'off';
				}
			}
			if(isset($advancesettings['productdetail']['showattribute']) && !empty($advancesettings['productdetail']['showattribute'])){
				foreach($advancesettings['productdetail']['showattribute'] as $_attr => $val){
					unset($disabled_attributes[$_attr]);
				}
				$advancesettings['productdetail']['showattribute'] = $disabled_attributes;
			}
			//echo '<pre>';print_r($advancesettings);exit;
			$collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
			$collection->addFieldToFilter('app_code', $data['appcode'])->addFieldToFilter('setting_code', 'advance_settings');

			$isMultiStoreView = Mage::helper('mobiadmin2')->isMultiStoreView();
			if($isMultiStoreView){
				$collection->addFieldToFilter('storeid', $storeid);
			}

			if($collection->getSize() > 0){
				foreach($collection as $_collection){
					$_collection->setData('value', serialize($advancesettings))->save();
				}
			}
			else{
				Mage::getModel('mobiadmin2/appsetting')->setData(array(
					'app_code'     => $data['appcode'],
					'setting_code' => 'advance_settings',
					'storeid'      => $isMultiStoreView ? $storeid : NULL,
					'value'        => serialize($advancesettings)
					))->save();
			}
		}
	}

	/**
	 * Created by Yash
	 * Date: 23-09-2015
	 */
	public function saveGoogleAnalyticsSettings($data)
	{
		if(isset($data['analyticsSettings']) && !empty($data['analyticsSettings'])){
			$analyticsSettings = $data['analyticsSettings'];
			$collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
			$collection->addFieldToFilter('app_code', $data['appcode'])->addFieldToFilter('setting_code', 'googleanalytics');
			if($collection->getSize() > 0){
				foreach($collection as $_collection){
					$_collection->setData('value', serialize($analyticsSettings))->save();
				}
			}
			else{
				Mage::getModel('mobiadmin2/appsetting')->setData(array(
					'app_code'     => $data['appcode'],
					'setting_code' => 'googleanalytics',
					'value'        => serialize($analyticsSettings)
					))->save();
			}
		}
	}
}