<?php
class Mobicommerce_Mobiadmin2_Model_Applications extends Mage_Core_Model_Abstract {
	
    protected function _construct()
    {
        $this->_init('mobiadmin2/applications');
    }

	public function saveApplicationData($data)
	{
		$appid = null;
		$errors = array();
		$groupId = $data['groupId'];
		if(Mage::helper('mobiadmin2')->isMultiStoreView()){
			$stores = Mage::app()->getStores();
		}
		else{
			$stores = Mage::app()->getGroup($groupId)->getStores();
		}

		$appcode = $data['app_code'];
		$appExist = Mage::getModel('mobiadmin2/applications')->getCollection()
			->addFieldToFilter('app_code', $appcode)
			->addFieldToFilter('app_key', $data['app_preview_code'])->count();
		if(!$appExist){
			$this->_create_mobi_media_dir($appcode, $data['app_theme_folder_name']);
			$applicationData = array(
				'app_name'         => $data['app_name'],
				'app_code'         => $appcode,
				'app_key'          => $data['app_preview_code'],
				'app_logo'         => $data['app_logo'],
				'app_license_key'  => $data['app_license_key'],
				'app_storegroupid' => $groupId,
				'app_mode'         => 'demo',
				'created_time'     => date('Y-m-d H:i:s'),
				'android_url'      => $data['android_url'],
				'android_status'   => $data['android_status'],
				'ios_url'          => $data['ios_url'],
				'ios_status'       => $data['ios_status'],
				'webapp_url'       => $data['webapp_url'],
				'udid'             => $data['udid'],
				'version_type'     => $data['version_type']
				);

			try{
				$appid = Mage::getModel('mobiadmin2/applications')->setData($applicationData)->save()->getId();
			}catch(Exception $e){
				$errors[] = $e->getMessage();   
			}

			$appinfo = serialize(array(
				'bundle_id'			   => 'com.mobicommerce.sampleapp',
				'iosappid'			   => '910995460',
				'android_appname'      => $data['app_name'],
				'android_appweburl'    => '',
				'android_appmobileurl' => '',
				'ios_appname'          => $data['app_name'],
				'ios_appweburl'        => '',
				'ios_appmobileurl'     => '',
				'app_description'      => 'Have you tried this app ?',
				'app_share_image'      => '',
				));

			Mage::getModel('mobiadmin2/appsetting')->setData(array(
				'app_code'     => $appcode,
				'setting_code' => 'appinfo',
				'value'        => $appinfo
				))->save();

			Mage::getModel('mobiadmin2/appsetting')->setData(array(
				'app_code'     => $appcode,
				'setting_code' => 'push_testdevices',
				'value'        => array()
				))->save();
	
			$pushValue = serialize(array(
				'active_push_notification' => 1,
				//'android_key'              => 'AIzaSyC5tw0jTUeFfcm2kvYMDk4AudnnF5DmJuM',
				'android_key'			   => 'AIzaSyAzvHE5MnSBq_R-SmBzgCqMn1vV03Khi2M',
				'android_sender_id'        => '881306584774',
				'upload_iospem_file'       => null,
				'upload_iospem_file_url'   => null,
				'pem_password'             => null,
				'sandboxmode'              => 0
				));

			Mage::getModel('mobiadmin2/appsetting')->setData(array(
				'app_code'     => $appcode,
				'setting_code' => 'push_notification',
				'value'        => $pushValue
				))->save();

			Mage::getModel('mobiadmin2/appsetting')->setData(array(
				'app_code'     => $appcode,
				'setting_code' => 'theme_folder_name',
				'value'        => $data['app_theme_folder_name']
				))->save();

			Mage::getModel('mobiadmin2/appsetting')->setData(array(
				'app_code'     => $appcode,
				'setting_code' => 'theme_android',
				'value'        => $data['theme_android']
				))->save();
			Mage::getModel('mobiadmin2/appsetting')->setData(array(
				'app_code'     => $appcode,
				'setting_code' => 'theme_ios',
				'value'        => $data['theme_ios']
				))->save();

			$cms_contents = array(
				"contact_information" => array(
					"company_name"    => "Your Company Name",
					"company_address" => "Your company addresss here",
					"phone_number"    => "+0-000-000-0000",
					"email_address"   => "mail@yourdomain.com",
					"latitude"        => "",
					"longitude"       => "",
					"zoom_level"      => "8",
					"pin_color"       => "000",
					),
				"social_media" => array(
					"facebook" => array(
						"checked" => "1",
						"url"     => "https://www.facebook.com/mobi.commerce.platform"
						),
					"twitter" => array(
						"checked" => "1",
						"url"     => "https://twitter.com/mobicommerceapp"
						),
					"linkedin" => array(
						"checked" => "0",
						"url"     => ""
						),
					"googleplus" => array(
						"checked" => "0",
						"url"     => ""
						),
					"youtube" => array(
						"checked" => "0",
						"url"     => ""
						),
					"pinterest" => array(
						"checked" => "0",
						"url"     => ""
						),
					"blog" => array(
						"checked" => "0",
						"url"     => ""
						),
					),
				"cms_pages" => array(),
				);
			$cmsdata = array(
				'app_code'     => $appcode,
				'setting_code' => 'cms_settings',
				'value'        => serialize($cms_contents)
				);

			foreach($stores as $_store){
				$cmsdata['storeid'] = $_store->getStoreId();
				Mage::getModel('mobiadmin2/appsetting')->setData($cmsdata)->save();
			}

			$googleanalytics = serialize(array(
				'android' => array(
					'status' => '1',
					'code'   => 'UA-715849-29'
					),
				'ios' => array(
					'status' => '1',
					'code'   => 'UA-715849-30'
					),
				));

			Mage::getModel('mobiadmin2/appsetting')->setData(array(
				'app_code'     => $appcode,
				'setting_code' => 'googleanalytics',
				'value'        => $googleanalytics
				))->save();

			$root_category_id = null;
			foreach (Mage::app()->getWebsites() as $website){
	            foreach ($website->getGroups() as $group){
	                if($group->getGroupId() == $groupId){
	                    $root_category_id = $group->getRootCategoryId();
	                }
	            }
	        }
			$children = Mage::getModel('catalog/category')->getCategories($root_category_id);
	        $categories = array();
	        if($children){
	            foreach ($children as $category) {
	                $categories[$category->getId()] = 'on';
	            }
	        }

	        $enable_image_resize = '0';
	        $timcache_url = Mage::getBaseUrl( Mage_Core_Model_Store::URL_TYPE_WEB, true ) . 'mobiresize.php?zc=1&sw=1366&do=Android&src='.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'mobi_assets/v/2/theme_files/shopper/professional/banners/banner1.jpg&mt=w_is';
	        $timcache_headers = get_headers($timcache_url, 1);
	        if(isset($timcache_headers['Content-Type']) && $timcache_headers['Content-Type'] == 'image/jpeg')
	        	$enable_image_resize = '1';

			$advanceSettings = array(
				'app_code'     => $appcode,
				'setting_code' => 'advance_settings',
				'value'        => serialize(array(
					"categories" => $categories,
					"image"      => array(
						"category" => "vertical_rectangle",
						"product"  => "vertical_rectangle",
						),
					"miscellaneous" => array(
						"enable_rating"				   => "1",
						"enable_wishlist"              => "1",
						"enable_socialsharing"         => "1",
						"enable_discountcoupon"        => "1",
						"enable_productsearch"         => "1",
						"enable_guestcheckout"         => "0",
						"enable_outofstock"            => "0",
						"enable_fixedheader"           => "1",
						"enable_estimatedshippingcost" => "0",
						"enable_categorywidget"		   => "1",
						"enable_storelocator"		   => "1",
						"enable_sociallogin"		   => "1",
						"enable_image_resize"		   => $enable_image_resize
						),
					"productlist" => array(
						"showname"                => "1",
						"showprice"               => "1",
						"showrating"              => "1",
						"enablesort"              => "1",
						"default_sorting"         => "popularity",
						"default_view"            => "list",
						"persistent_view"		  => "1",
						"enablechangeproductview" => "1",
						"enablefilter"            => "1"
						),
					"productdetail" => array(
						"enable_productzoom"       => "1",
						"enable_endless_slider"    => "0",
						"enable_youmaylike_slider" => "1",
						"showattribute"            => array(),
						)
					))
				);
			
			if(Mage::helper('mobiadmin2')->isMultiStoreView()){
				foreach($stores as $_store){
					$advanceSettings['storeid'] = $_store->getStoreId();
					Mage::getModel('mobiadmin2/appsetting')->setData($advanceSettings)->save();
				}
			}
			else{
				Mage::getModel('mobiadmin2/appsetting')->setData($advanceSettings)->save();
			}

			$this->setDefaultWidgetData($appcode, $groupId, $data['version_type'], $data['app_theme_folder_name'], $categories);
        }
		return array(
			'appid' => $appid,
			'errors' => $errors
			);
	}

	public function setDefaultWidgetData($appcode, $groupId, $version_type, $theme, $categories)
	{
		//professional
		if($version_type == '001'){
			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'professional'.DS.'banners'.DS.'banner1.jpg', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'home_banners'.DS.'banner1.jpg');
			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'professional'.DS.'banners'.DS.'banner2.jpg', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'home_banners'.DS.'banner2.jpg');

			$widgets = array(
				// image banner
				array(
					'widget_label'    => 'Banners',
					'widget_code'     => 'widget_image_slider',
					'widget_status'   => '1',
					'widget_position' => '1',
					'widget_data'     => array(
						'title'                    => '',
						'title_align'              => 'center',
						'show_bullet'              => '1',
						'slide_auto_play'          => '0',
						'play_loop'                => '0',
						'slide_auto_play_interval' => '5000',
						'banners'                  => array(
							array(
								'banner_options'  => '1',
								'banner_url'      => Mage::getBaseUrl('media').'mobi_commerce/'.$appcode.'/home_banners/banner1.jpg',
								'banner_position' => '1',
								'banner_status'   => '1',
								'banner_link'     => $this->getBannerLink($categories),
								'banner_delete'   => '0'
								),
							array(
								'banner_options'  => '2',
								'banner_url'      => Mage::getBaseUrl('media').'mobi_commerce/'.$appcode.'/home_banners/banner2.jpg',
								'banner_position' => '2',
								'banner_status'   => '1',
								'banner_link'     => $this->getBannerLink($categories),
								'banner_delete'   => '0'
								),
							)
						)
					),
				// category widget
				array(
					'widget_label'    => 'Category',
					'widget_code'     => 'widget_category',
					'widget_status'   => '1',
					'widget_position' => '2',
					'widget_data'     => array(
						'title'                      => 'Shop by Category',
						'title_align'                => 'left',
						'link_all_product'           => 'no',
						'cat_layout'                 => 'list',
						'category_force_product_nav' => '0',
						'show_thumbnail'             => '0',
						'show_name'                  => '1',
						'categories'                 => array('id' => json_encode($categories)),
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Product Slider',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '3',
					'widget_data'     => array(
						'title'              => 'New Arivals',
						'title_align'        => 'left',
						'type'               => 'slider',
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'newarrivals',
						'products'           => array('id' => json_encode(array())),
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Product Slider',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '4',
					'widget_data'     => array(
						'title'              => 'Hot Products',
						'title_align'        => 'left',
						'type'               => 'slider',
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'selected',
						'products'           => array('id' => json_encode(array())),
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Product Slider',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '5',
					'widget_data'     => array(
						'title'              => 'Best Offers',
						'title_align'        => 'left',
						'type'               => 'slider',
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '0',
						'productslider_type' => 'selected',
						'products'           => array('id' => json_encode(array())),
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Product Slider',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '6',
					'widget_data'     => array(
						'title'              => 'Recently Viewed',
						'title_align'        => 'left',
						'type'               => 'slider',
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '0',
						'productslider_type' => 'productviewed',
						'products'           => array('id' => json_encode(array())),
						)
					),
			);
		}
		// enterprise
		else if($version_type == '002'){
			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'enterprise'.DS.'banners'.DS.'banner1.png', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'home_banners'.DS.'banner1.png');
			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'enterprise'.DS.'banners'.DS.'banner2.png', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'home_banners'.DS.'banner2.png');
			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'enterprise'.DS.'banners'.DS.'banner3.png', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.$appcode.DS.'home_banners'.DS.'banner3.png');

			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'enterprise'.DS.'image'.DS.'image1.png', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'widget_image'.DS.$appcode.'image1.png');
			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'enterprise'.DS.'image'.DS.'image10.png', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'widget_image'.DS.$appcode.'image10.png');
			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'enterprise'.DS.'image'.DS.'image20.png', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'widget_image'.DS.$appcode.'image20.png');
			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'enterprise'.DS.'image'.DS.'image30.png', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'widget_image'.DS.$appcode.'image30.png');

			@copy(Mage::getBaseDir('media').DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$theme.DS.'enterprise'.DS.'separator'.DS.'separator1.png', Mage::getBaseDir('media').DS.'mobi_commerce'.DS.'widget_image'.DS.$appcode.'separator1.png');

			$widgets = array(
				// image banner
				array(
					'widget_label'    => 'Top Banners',
					'widget_code'     => 'widget_image_slider',
					'widget_status'   => '1',
					'widget_position' => '1',
					'widget_data'     => array(
						'title'                    => '',
						'title_align'              => 'center',
						'show_bullet'              => '1',
						'slide_auto_play'          => '0',
						'play_loop'                => '1',
						'slide_auto_play_interval' => '5000',
						'banners'                  => array(
							array(
								'banner_options'  => '1',
								'banner_url'      => Mage::getBaseUrl('media').'mobi_commerce/'.$appcode.'/home_banners/banner1.png',
								'banner_position' => '1',
								'banner_status'   => '1',
								'banner_link'     => $this->getBannerLink($categories),
								'banner_delete'   => '0'
								),
							array(
								'banner_options'  => '2',
								'banner_url'      => Mage::getBaseUrl('media').'mobi_commerce/'.$appcode.'/home_banners/banner2.png',
								'banner_position' => '2',
								'banner_status'   => '1',
								'banner_link'     => $this->getBannerLink($categories),
								'banner_delete'   => '0'
								),
							array(
								'banner_options'  => '2',
								'banner_url'      => Mage::getBaseUrl('media').'mobi_commerce/'.$appcode.'/home_banners/banner3.png',
								'banner_position' => '2',
								'banner_status'   => '1',
								'banner_link'     => $this->getBannerLink($categories),
								'banner_delete'   => '0'
								),
							)
						)
					),
				// image widget
				array(
					'widget_label'    => 'Flat 40% Discount',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '2',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '<img src="'.Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'image1.png" alt="" usemap="#map'.$appcode.'image1"><map id="map'.$appcode.'image1" name="map'.$appcode.'image1"><area shape="rect" coords="1,3,1035,287" title="undefined" alt="undefined" href="'.$this->getBannerLink($categories).'" target="_self"><area shape="rect" coords="1033,285,1034,286" alt="Image HTML map generator" title="HTML Map creator" href="" target="_self"></map>',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'image1.png',
						)
					),
				// separator
				array(
					'widget_label'    => 'Separator',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '3',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'separator1.png',
						)
					),
				// category widget
				array(
					'widget_label'    => 'Shop by Category',
					'widget_code'     => 'widget_category',
					'widget_status'   => '1',
					'widget_position' => '4',
					'widget_data'     => array(
						'title'                      => 'SHOP BY CATEGORY',
						'title_align'                => 'left',
						'link_all_product'           => 'no',
						'cat_layout'                 => 'list',
						'category_force_product_nav' => '0',
						'show_thumbnail'             => '0',
						'show_name'                  => '1',
						'categories'                 => array('id' => json_encode($categories)),
						)
					),
				// separator
				array(
					'widget_label'    => 'Separator',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '5',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'separator1.png',
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'New Arrivals',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '6',
					'widget_data'     => array(
						'title'              => 'NEW ARRIVALS',
						'title_align'        => 'left',
						'type'               => 'slider',
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'newarrivals',
						'products'           => array('id' => json_encode(array())),
						)
					),
				// separator
				array(
					'widget_label'    => 'Separator',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '7',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'separator1.png',
						)
					),
				// image widget
				array(
					'widget_label'    => 'Hot Deals',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '8',
					'widget_data'     => array(
						'title'        => 'HOT DEALS',
						'title_align'  => 'left',
						'mapcode'      => '<img src="'.Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'image10.png" alt="" usemap="#map'.$appcode.'image10.png"><map id="map'.$appcode.'image10.png" name="map'.$appcode.'image10.png"><area shape="rect" coords="2,2,494,495" title="undefined" alt="undefined" href="'.$this->getBannerLink($categories).'" target="_self"><area shape="rect" coords="500,4,999,245" title="undefined" alt="undefined" href="'.$this->getBannerLink($categories).'" target="_self"><area shape="rect" coords="504,254,1004,495" title="undefined" alt="undefined" href="'.$this->getBannerLink($categories).'" target="_self"><area shape="rect" coords="1002,493,1003,494" alt="Image HTML map generator" title="HTML Map creator" href="" target="_self"></map>',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'image10.png',
						)
					),
				// separator
				array(
					'widget_label'    => 'Separator',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '9',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'separator1.png',
						)
					),
				// image widget
				array(
					'widget_label'    => 'Winter Fashion Collection',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '10',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '<img src="'.Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'image20.png" alt="" usemap="#map'.$appcode.'image20"><map id="map'.$appcode.'image20" name="map'.$appcode.'image20"><area shape="rect" coords="3,0,1047,302" title="undefined" alt="undefined" href="'.$this->getBannerLink($categories).'" target="_self"><area shape="rect" coords="1080,300,1081,301" alt="Image HTML map generator" title="HTML Map creator" href="" target="_self"></map>',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'image20.png',
						)
					),
				// separator
				array(
					'widget_label'    => 'Separator',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '11',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'separator1.png',
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Trending now',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '12',
					'widget_data'     => array(
						'title'              => 'TRENDING NOW',
						'title_align'        => 'left',
						'type'               => 'slider',
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'selected',
						'products'           => array('id' => json_encode(array())),
						)
					),
				// separator
				array(
					'widget_label'    => 'Separator',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '13',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'separator1.png',
						)
					),
				// product slider widget
				array(
					'widget_label'    => 'Recently viewed Products',
					'widget_code'     => 'widget_product_slider',
					'widget_status'   => '1',
					'widget_position' => '14',
					'widget_data'     => array(
						'title'              => 'RECENTLY VIEWED',
						'title_align'        => 'left',
						'type'               => 'slider',
						'show_name'          => '1',
						'show_price'         => '1',
						'show_review'        => '1',
						'productslider_type' => 'productviewed',
						'products'           => array('id' => json_encode(array())),
						)
					),
				// separator
				array(
					'widget_label'    => 'Separator',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '15',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'separator1.png',
						)
					),
				// image widget
				array(
					'widget_label'    => 'Bottom Support Image',
					'widget_code'     => 'widget_image',
					'widget_status'   => '1',
					'widget_position' => '16',
					'widget_data'     => array(
						'title'        => '',
						'title_align'  => 'center',
						'mapcode'      => '<img src="'.Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'image30.png" alt="" usemap="#map'.$appcode.'image30"><map id="map'.$appcode.'image30" name="map'.$appcode.'image30"><area shape="rect" coords="530,172,1051,323" title="" alt="" href="phone||000000000000" target=""><area shape="rect" coords="1058,321,1059,322" alt="Image HTML map generator" title="HTML Map creator" href="" target="_self"></map>',
						'widget_image' => Mage::getBaseUrl('media').'mobi_commerce/widget_image/'.$appcode.'image30.png',
						)
					),
			);
		}
		
		if(Mage::helper('mobiadmin2')->isMultiStoreView()){
			$stores = Mage::app()->getStores();
		}
		else{
			$stores = Mage::app()->getGroup($groupId)->getStores();
		}
		foreach($stores as $_store){
			foreach($widgets as $key => $value){
				$_widget = $value;
				$_widget['widget_app_code'] = $appcode;
				$_widget['widget_store_id'] = $_store->getStoreId();
				if($_widget['widget_code'] == 'widget_product_slider'){
					if($_widget['widget_data']['productslider_type'] == 'selected'){
						$_products = $this->_getRandomProducts($_store->getStoreId(), 10);
						$value['widget_data']['products'] = array('id' => json_encode($_products));
					}
				}
				$_widget['widget_data'] = serialize($value['widget_data']);

				Mage::getModel('mobiadmin2/widget')->setData($_widget)->save();
			}
		}
		//echo '<pre>';print_r($widgets);exit;
	}

	protected function getBannerLink($categories)
	{
		if(!empty($categories))
			return 'category||'.array_rand($categories);

		return '';
	}

	public function _getRandomProducts($storeId, $limit=10)
	{
		$products = Mage::getModel('catalog/product')
			->getCollection()
            ->addAttributeToFilter('status', '1')
			->addAttributeToFilter('visibility', '4')
			->setStoreId($storeId);
		$products->getSelect()->limit($limit);

		$productsArray = array();
		if($products->getSize() > 0){
			foreach($products as $_product){
				$productsArray[$_product->getId()] = null;
			}
		}

		return $productsArray;
	}

	protected function _create_mobi_media_dir($app_code = null, $app_theme_folder_name = null)
	{
        $base_dir = Mage::getBaseDir('media');
        if(!(is_dir($base_dir.'/mobi_commerce') && file_exists($base_dir.'/mobi_commerce')))
            mkdir($base_dir.'/mobi_commerce', 0777, true);

        if(!(is_dir($base_dir.'/mobi_commerce/widget_image') && file_exists($base_dir.'/mobi_commerce/widget_image')))
            mkdir($base_dir.'/mobi_commerce/widget_image', 0777, true);

        if(!(is_dir($base_dir.'/mobi_commerce/'.$app_code) && file_exists($base_dir.'/mobi_commerce/'.$app_code)))
            mkdir($base_dir.'/mobi_commerce/'.$app_code, 0777, true);

        if(!(is_dir($base_dir.'/mobi_commerce/'.$app_code.'/home_banners') && file_exists($base_dir.'/mobi_commerce/'.$app_code.'/home_banners')))
            mkdir($base_dir.'/mobi_commerce/'.$app_code.'/home_banners', 0777, true);

        if(!(is_dir($base_dir.'/mobi_commerce/'.$app_code.'/appinfo') && file_exists($base_dir.'/mobi_commerce/'.$app_code.'/appinfo')))
            mkdir($base_dir.'/mobi_commerce/'.$app_code.'/appinfo', 0777, true);

        if(!(is_dir($base_dir.'/mobi_commerce/'.$app_code.'/personalizer') && file_exists($base_dir.'/mobi_commerce/'.$app_code.'/personalizer'))){
            mkdir($base_dir.'/mobi_commerce/'.$app_code.'/personalizer', 0777, true);
            mkdir($base_dir.'/mobi_commerce/'.$app_code.'/personalizer/svg', 0777, true);

            if(!empty($app_theme_folder_name)){
                @copy($base_dir.DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$app_theme_folder_name.DS.'personalizer'.DS.'personalizer.xml', $base_dir.DS.'mobi_commerce'.DS.$app_code.DS.'personalizer'.DS.'personalizer.xml');
                @copy($base_dir.DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$app_theme_folder_name.DS.'personalizer'.DS.'personalizer.css', $base_dir.DS.'mobi_commerce'.DS.$app_code.DS.'personalizer'.DS.'personalizer.css');
            }
        }

        if(!empty($app_theme_folder_name)){
            $dir = $base_dir.DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$app_theme_folder_name.DS.'personalizer'.DS.'svg';
            if(file_exists($dir)){
                $scandir = scandir($dir);
                foreach ($scandir as $key => $value) 
                { 
                    if (!in_array($value,array(".",".."))) 
                    {
                        $currfile = $dir . DIRECTORY_SEPARATOR . $value;
                        if (!is_dir($currfile))
                        {
                            $filename = PATHINFO($value, PATHINFO_BASENAME);
                            if(!file_exists($base_dir.DS.'mobi_commerce'.DS.$app_code.DS.'personalizer'.DS.'svg'.DS.$filename)){
                                @copy($base_dir.DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$app_theme_folder_name.DS.'personalizer'.DS.'svg'.DS.$filename, $base_dir.DS.'mobi_commerce'.DS.$app_code.DS.'personalizer'.DS.'svg'.DS.$filename);
                            }
                        }
                    } 
                }
            }

            $sourcePersonalizerFolder = $base_dir.DS.'mobi_assets'.DS.'v'.DS.Mage::helper('mobiadmin2')->getMobiBaseVersion().DS.'theme_files'.DS.$app_theme_folder_name.DS.'personalizer';
            $destinationPersonalizerFolder = $base_dir.DS.'mobi_commerce'.DS.$app_code.DS.'personalizer';

            $sourcePersonalizerXml = $sourcePersonalizerFolder.DS.'personalizer.xml';
            $destinationPersonalizerXml = $destinationPersonalizerFolder.DS.'personalizer.xml';

            if(file_exists ($destinationPersonalizerXml)){
                $sourcePersonalizerXml = (array) simplexml_load_file($sourcePersonalizerXml);
                $destinationPersonalizerXml = (array) simplexml_load_file($destinationPersonalizerXml);
                $destinationPersonalizerCss = $destinationPersonalizerFolder.DS.'personalizer.css';
                $cssArray = array();

                $doc = new DOMDocument('1.0');
                $doc->formatOutput = true;
                $root = $doc->createElement('mobicommerce_personalizer');
                $root = $doc->appendChild($root);

                foreach($sourcePersonalizerXml as $key => $element){
                    $css = $element->css;
                    $svgFilenames = (string) $element->svg_filenames;
                    $defaultValue = (string) $element->default_value;
                    $currentValue = (string) $element->default_value;
                    if(isset($destinationPersonalizerXml[$key])){
                        $currentValue = (string) $destinationPersonalizerXml[$key]->current_value;
                    }
                    $css = implode("\r\n", explode('|', $css));
                    $cssArray[] = str_replace("--COLOR--", $currentValue, $css);

                    if(!empty($svgFilenames)){
                        $svgFilenames = explode('|', $svgFilenames);
                        if(!empty($svgFilenames)){
                            foreach($svgFilenames as $svg_filename){
                                if(file_exists($sourcePersonalizerFolder . DS . 'svg' . DS . $svg_filename)){
                                    $svg_image = file_get_contents($sourcePersonalizerFolder . DS . 'svg' . DS . $svg_filename);
                                    preg_match_all('/<style>(.*?)<\/style>/s', $svg_image, $style_tag);
                                    $old_style_tag = $style_tag[1][0];
                                    $property = explode('{', $style_tag[1][0]);
                                    $property = $property[0];
                                    preg_match_all('/{(.*?)}/s', $style_tag[1][0], $style_tag);
                                    $param = explode(':', $style_tag[1][0]);
                                    $param = $param[0];
                                    $new_style_tag = $property.'{'.$param.':'.$currentValue.'!important;}';
                                    $svg_image = str_replace($old_style_tag, $new_style_tag, $svg_image);
                                    file_put_contents($destinationPersonalizerFolder . DS . 'svg' . DS . $svg_filename, $svg_image);
                                }
                            }
                        }
                    }

                    $newdoc = $root->appendChild($doc->createElement($key));
                    foreach($element as $optioncode => $value){
                        $em = $doc->createElement($optioncode);
                        if($optioncode == 'current_value'){
                            $value = $currentValue;
                        }
                        else if($optioncode == 'default_value'){
                            $value = $defaultValue;
                        }
                        $text = $doc->createTextNode($value);
                        $em->appendChild($text);
                        $newdoc->appendChild($em);
                    }
                }
                file_put_contents($destinationPersonalizerCss, implode($cssArray, "\r\n"));
                $doc->save($destinationPersonalizerFolder.DS.'personalizer.xml');
            }
        }
    }

	public function deleteapps($appcodes = array()) 
	{
		$deleteCount = 0;
		if(!empty($appcodes)){
			$appcodes = array_filter(array_unique(array_map('trim', $appcodes)));
			if(!empty($appcodes)){
				$records = Mage::getModel('mobiadmin2/appsetting')->getCollection()->addFieldToFilter('app_code',array('in' => $appcodes));
				if($records->count()){
					foreach($records as $_record){
						$_record->delete();
					}
				}

				$records = Mage::getModel('mobiadmin2/widget')->getCollection()->addFieldToFilter('widget_app_code',array('in' => $appcodes));
				if($records->count()){
					foreach($records as $_record){
						$_record->delete();
					}
				}

				$records = Mage::getModel('mobiadmin2/devicetokens')->getCollection()->addFieldToFilter('md_appcode',array('in' => $appcodes));
				if($records->count()){
					foreach($records as $_record){
						$_record->delete();
					}
				}

				$records = Mage::getModel('mobiadmin2/applications')->getCollection()->addFieldToFilter('app_code',array('in' => $appcodes));
				if($records->count()){
					foreach($records as $_record){
						$deleteCount++;
						$_record->delete();
					}
				}

				foreach($appcodes as $_appcode){
					$dir = Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA) . DS . 'mobi_commerce' . DS . $_appcode;
					if(file_exists($dir) && is_dir($dir)){
						Mage::helper('mobiservices2/mobicommerce')->rrmdir($dir);
					}
				}
			}
		}
        return $deleteCount;
	}
}