<?php
class Mobicommerce_Mobiadmin2_Block_Adminhtml_Applications_Edit_Tab_Advancesettings extends Mage_Adminhtml_Block_Widget_Form {
	
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('mobiadmin2/application/edit/tab/advancesettings.phtml');
    }

    public function getAdvanceSettings()
    {
    	$appdata = Mage::registry('application_data');
		$appcode = $appdata->getAppCode();
        $store = Mage::app()->getRequest()->getParam('store', 0);

		$collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
		$collection->addFieldToFilter('app_code', $appcode)->addFieldToFilter('setting_code','advance_settings');
        if(Mage::helper('mobiadmin2')->isMultiStoreView()){
            $collection->addFieldToFilter('storeid', $store);
        }
		if($collection->getSize() > 0){
			return @unserialize($collection->getFirstItem()->getValue());
		}
		return null;
    }

    public function getFirstLevelCategories()
    {
        $appdata = Mage::registry('application_data');
        $groupId = $appdata->getAppStoregroupid();
        $root_category_id = null;
        $store = Mage::app()->getRequest()->getParam('store', 0);
        if(!empty($store)){
            foreach (Mage::app()->getWebsites() as $website){
                foreach ($website->getGroups() as $group){
                    foreach ($group->getStores() as $_store){
                        if($_store->getId() == $store){
                            $root_category_id = $group->getRootCategoryId();
                        }
                    }
                }
            }
        }
        else{
            foreach (Mage::app()->getWebsites() as $website){
                foreach ($website->getGroups() as $group){
                    if($group->getGroupId() == $groupId){
                        $root_category_id = $group->getRootCategoryId();
                    }
                }
            }
        }

        $root_category = Mage::getModel('catalog/category')->load($root_category_id);
        $children = $root_category->getChildren();
        //$children = Mage::getModel('catalog/category')->getCategories($root_category_id);
        $categories = array();
        if($children){
            //foreach ($children as $category) {
            foreach(explode(',',$children) as $category) {
                $category = Mage::getModel('catalog/category')->load($category);
                $categories[] = array(
                    'id'   => $category->getId(),
                    'name' => $category->getName(),
                    );
            }
        }
        return $categories;
    }
}