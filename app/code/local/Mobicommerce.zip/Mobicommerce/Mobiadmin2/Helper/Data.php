<?php
class Mobicommerce_Mobiadmin2_Helper_Data extends Mage_Core_Helper_Abstract {
	
	public $productInstance;
	protected $mobibaseversion = '2';

	public function getMobiBaseVersion()
	{
		return $this->mobibaseversion;
	}

	public function getAppCmsPage()
	{
		$appdata = Mage::registry('application_data');
		$appcode = $appdata->getAppCode();
		$storeid = Mage::app()->getRequest()->getParam('store', null);

		$collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
		$collection->addFieldToFilter('app_code', $appcode)->addFieldToFilter('setting_code','cms_settings');
		$collection->addFieldToFilter('storeid', $storeid);
		$data = $collection->getFirstItem()->getValue();
		$data = Mage::helper('mobiadmin2')->_jsonUnserialize($data);
		return $data;
	}

	public function getProductAttributes()
	{
		$attributes = array(
    		array(
				'code'  => 'default_short_description',
				'label' => 'Default Short Description'
    			),
    		array(
				'code'  => 'default_long_description',
				'label' => 'Default Long Description'
    			),
    		);
    	$excludeAttr = array();
    	$attr = Mage::getResourceModel('catalog/product_attribute_collection');
    	if($attr){
    		foreach ($attr as $_attr) {
    			if($_attr->getIsVisibleOnFront() && !in_array($_attr->getAttributeCode(), $excludeAttr)){
    				$attributes[] = array(
						'code'  => $_attr->getAttributeCode(),
						'label' => $_attr->getFrontendLabel(),
    					);
    			}
			}
    	}

    	return $attributes;
	}

	public function getAppLocaleCode()
	{
		$storeid = Mage::app()->getRequest()->getParam('store', null);
		$locale = Mage::getStoreConfig('general/locale/code', $storeid);
		return $locale;
	}

	public function getProductCollectionForSlider()
	{
		$cats = array();
		//$categories = array(26);
		$categories = array();
		if(!empty($categories)){
			foreach ($categories as $_category) {
				$cats[] = $_category;
				$catetory = Mage::getModel('catalog/category')->load($_category);
				$subcats = $catetory->getAllChildren();
				if(!empty($subcats)){
					$cats = array_merge($cats, explode(',', $subcats));
				}
				$cats = array_unique($cats);
			}
		}

		$storeid = Mage::app()->getRequest()->getParam('store', null);
		$collection = Mage::getModel('catalog/product')->getCollection()
			->setStoreId($storeid)
			->addAttributeToSelect('*')
			//->addAttributeToFilter('type_id', array('eq' => 'grouped'))
			//->joinField('category_id', 'catalog/category_product', 'category_id', 'product_id = entity_id', null, 'left')
			//->addAttributeToFilter('category_id', array('in' => $cats))
			->addAttributeToFilter('status', array('eq' => Mage_Catalog_Model_Product_Status::STATUS_ENABLED));

		$collection->getSelect()->group('e.entity_id');

		Mage::getSingleton('catalog/product_visibility')->addVisibleInCatalogFilterToCollection($collection);
		Mage::getSingleton('catalog/product_status')->addVisibleFilterToCollection($collection);
		Mage::getSingleton('cataloginventory/stock')->addInStockFilterToCollection($collection);
		$collection->setPageSize(200);
		return $collection;
	}

	public function getBestSellerProduct($storeid)
	{  
		$collection = Mage::getResourceModel('catalog/product_collection')
            ->addAttributeToSelect(Mage::getSingleton('catalog/config')->getProductAttributes())
            ->addStoreFilter()
            ->setPageSize(10);
        $collection->getSelect()
            ->joinLeft(
                array('aggregation' => $collection->getResource()->getTable('sales/bestsellers_aggregated_monthly')),
                "e.entity_id = aggregation.product_id AND aggregation.store_id={$storeid}",
                array('SUM(aggregation.qty_ordered) AS sold_quantity')
            )
            ->group('e.entity_id')
            ->order(array('sold_quantity DESC', 'e.created_at'))
			->limit(10);
		
		return $collection;     
	}

	public function getNewProductCollection($storeid)
	{
		$todayDate = Mage::app()->getLocale()->date()->toString(Varien_Date::DATETIME_INTERNAL_FORMAT);
        $collection = Mage::getModel('catalog/product')->setStoreId($storeid)
			->getCollection()
			->addAttributeToFilter('news_from_date', array('date' => true, 'to' => $todayDate))
			->addAttributeToFilter('news_to_date', array('or'=> array(
			    0 => array('date' => true, 'from' => $todayDate),
			    1 => array('is' => new Zend_Db_Expr('null')))
			), 'left')
			->addAttributeToSort('news_from_date', 'desc')
			->addAttributeToSort('created_at', 'desc'); 
		$collection->getSelect()->limit(10);
		return $collection;		
	}

	public function getThemeName($appcode)
	{
		$collection = Mage::getModel('mobiadmin2/appsetting')->getCollection()
			->addFieldToFilter('app_code', $appcode)
			->addFieldToFilter('setting_code', 'theme_folder_name');
		$data = $collection->getData();
		return $data['0']['value'];
	}

	public function setLanguageCodeData($locale)
	{
		if($locale != 'en_US' && !file_exists(Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_assets/multilanguage/'.$locale.'.xml'))
			@copy(Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_assets/multilanguage/en_US.xml', Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_assets/multilanguage/'.$locale.'.xml');

		$xml = Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_commerce/multilanguage/'.$locale.'.xml';
		if(!file_exists($xml)){
			if(!file_exists(Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_commerce/multilanguage'))
				mkdir(Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_commerce/multilanguage', 0755);

			if(file_exists(Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_assets/multilanguage/'.$locale.'.xml')){
				@copy(Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_assets/multilanguage/'.$locale.'.xml', Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_commerce/multilanguage/'.$locale.'.xml');
			}
			else
				@copy(Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_assets/multilanguage/'.$locale.'.xml', Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_commerce/multilanguage/en_US.xml');
		}
	}

	public function getLanguageData($locale)
	{
		$this->setLanguageCodeData($locale);
		$labels = array();

		$xml = Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_assets/multilanguage/'.$locale.'.xml';
        $xmldata = simplexml_load_file($xml);
        foreach($xmldata as $_key => $_data){
        	$labels[$_key] = (array)$_data;
        }

        $childxml = Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA).'/mobi_commerce/multilanguage/'.$locale.'.xml';
        $childxmldata = simplexml_load_file($childxml);
        foreach($childxmldata as $_key => $_data){
        	if(array_key_exists($_key, $labels)){
        		$labels[$_key]['mm_text'] = (string)$_data->mm_text;
        	}
        }

		return $labels;
	}

	public function _jsonUnserialize($data = null)
	{
		$jsonData = json_decode($data, true);
		if(is_array($jsonData)){
			return $jsonData;
		}
		else{
			return @unserialize($data);
		}
	}

	public function buyNowUrl($version)
	{
		$baseurl = 'http://www.mobicommerce.net/mobiweb/index/';
		if($version == '001')// professional
			return $baseurl.'addtocart';
		else if($version == '002')// enterprise
			return $baseurl.'addtocartbyoption';
		else
			return 'addtocart';
	}

	public function getCountUnreadNotification()
	{
		$table = Mage::getSingleton('core/resource')->getTableName('mobicommerce_notification');
		$tableExists = Mage::getSingleton('core/resource')->getConnection('core_write')->showTableStatus($table);
		if($tableExists){
			$collection = Mage::getModel('mobiadmin2/notification')->getCollection()->addFieldToFilter('read_status', '0');
			return $collection->count();
		}
		return 0;
	}

	public function curlBuildUrl()
	{
		return 'http://build.mobi-commerce.net/';
	}

	public function mobicommerceEmailId()
	{
		return 'plugin@mobicommerce.net';
	}
	
	public function getLocaleLabel($locale)
	{
		$locales = Mage::app()->getLocale()->getOptionLocales();
		foreach($locales as $_locale){
			if($_locale['value'] == $locale){
				return $_locale['label'];
			}
		}
	}

	public function getAllChildCategories($category, $result = array(), $firstcall = true)
	{
		$children = Mage::getResourceModel('catalog/category_collection')
			->addAttributeToSelect('*')
			->addAttributeToFilter('is_active', array('in' => array(0,1)))
			->addAttributeToFilter('parent_id', $category)
            ->getData();
                
        if(!$firstcall){
			$result[] = $category;
		}
                
        foreach($children as $child){
            $result[] = $child['entity_id'];
            if($child['children_count'] > 0){
                $result1 = $this->getAllChildCategories($child['entity_id'], $result, false);
				$result = array_unique(array_merge($result, $result1));
            }
        }
		return $result;
	}

	/**
	 * deprected function
	 * for some customers below function was not working
	 */
	public function __getAllChildCategories($category, $result = array(), $firstcall = true)
	{
		$cat = Mage::getModel('catalog/category')->load($category);
		if(!$firstcall){
			$result[] = $category;
		}
		$subcats = $cat->getChildren();
		if($subcats){
			foreach(explode(',', $subcats) as $_subcat)
			{
			  	$result1 = $this->getAllChildCategories($_subcat, $result, false);
			  	$result = array_merge($result, $result1);
			}
		}
		return $result;
	}

	public function getTestDevices($appcode)
	{
		$collection = Mage::getModel('mobiadmin2/appsetting')->getCollection();
        $collection->addFieldToFilter('app_code', $appcode)->addFieldToFilter('setting_code','push_testdevices');
        $emails = array();
        if($collection->getSize() > 0){
            $emails = @unserialize($collection->getFirstItem()->getValue());
        }

        $pushUsers = array();
        $devices = array();
        $androidDevices = array();
        $iosDevices = array();

        if(!empty($emails)){
            foreach($emails as $_email){
                $pushUsers[$_email] = array(
                    'name'           => null,
                    'androiddevices' => 0,
                    'iosdevices'     => 0
                    );
            }

            $collection = Mage::getResourceModel('customer/customer_collection')
                ->addAttributeToSelect('id')
                ->addAttributeToSelect('firstname')
                ->addAttributeToSelect('lastname')
                ->addAttributeToSelect('email')
                ->addAttributeToFilter('email', array('in' => $emails));

            $userids = array();
            foreach($collection as $_collection){
                $pushUsers[$_collection->getEmail()]['name'] = $_collection->getFirstname();
                $userids[] = $_collection->getId();
            }

            $deviceCollection = Mage::getModel('mobiadmin2/devicetokens')->getCollection()
                ->addFieldToFilter('md_appcode',$appcode)
                ->addFieldToFilter('md_userid', array('in' => $userids))
                ->addFieldToFilter('md_devicetype',array('in' => array('android','ios')));

            $prefix = Mage::getConfig()->getTablePrefix();
            $deviceCollection->getSelect()->joinLeft(
                array(
                    "ce" => $prefix.'customer_entity'
                    ),
                'main_table.md_userid=ce.entity_id',
                array("email" => "ce.email")
                );

            //echo $deviceCollection->getSelect()->__toString();
            if($deviceCollection->getSize()){
                foreach($deviceCollection as $_collection){
                    if($_collection->getMdDevicetype() == 'android'){
                        $androidDevices[] = $_collection->getMdDevicetoken();
                        $pushUsers[$_collection->getEmail()]['androiddevices']++;
                    }
                    else if($_collection->getMdDevicetype() == 'ios'){
                        $iosDevices[] = $_collection->getMdDevicetoken();
                        $pushUsers[$_collection->getEmail()]['iosdevices']++;
                    }
                }
            }
        }
        //print_r($pushUsers);
        return array(
            'devices' => array(
                'android' => $androidDevices,
                'ios'     => $iosDevices
                ),
            'users'   => $pushUsers,
            'emails'  => $emails
            );
	}

	public function getMobicommercePrerequisites()
	{
		$prerequisites = array();
		// dont want to shwo error any more as it confuses user.
		// date: 20-04-16
		return $prerequisites;

		$mediaPath = Mage::getBaseDir();
		if(0644 !== (fileperms(Mage::getBaseDir() . '/mobiresize.php') & 0777))
			$prerequisites[] = "mobiresize.php does not have 644 permission. Kindly set 644 permission";
		if(0755 !== (fileperms(Mage::getBaseDir('media') . '/timcache') & 0777))
			$prerequisites[] = "media/timcache does not have 755 permission. Kindly set 755 permission";
		$max_execution_time = ini_get('max_execution_time');
		if($max_execution_time != -1 && $max_execution_time < 300){
			$prerequisites[] = "Your max_execution_time is less then 300 seconds. Please increase it to 300 seconds or above.";
		}
		$max_input_time = ini_get('max_input_time');
		if($max_input_time != -1 && $max_input_time < 300){
			$prerequisites[] = "Your max_input_time is less then 300 seconds. Please increase it to 300 seconds or above.";
		}

		if(!empty($prerequisites)){
			foreach($prerequisites as $_prerequisite){
				Mage::getSingleton('core/session')->addError($_prerequisite);
			}
		}

		return $prerequisites;
	}

	/**
	 * added by Yash
	 * date: 26-08-2016
	 * some clients want multiple stores instead of single store application
	 * so return true in that case
	 */
	public function isMultiStoreView()
	{
            return true;
            //return false;
	}
}